------------------------------------------------------------
-- SpoonManager Spoon
--
-- Menu central pour activer/desactiver les Spoons locaux.
------------------------------------------------------------


local obj = {}

obj.__index = obj



------------------------------------------------------------
-- METADONNEES
------------------------------------------------------------

obj.name = "SpoonManager"

obj.version = "1.0.0"

obj.author = "Benjamin Cerede / OpenAI"

obj.homepage = "Local Spoon"

obj.license = "MIT"



------------------------------------------------------------
-- CONFIGURATION PUBLIQUE
------------------------------------------------------------

obj.menuTitle = "⚙️"

obj.settingsKey = "SpoonManager.enabledSpoons"

obj.showNotifications = true

obj.spoons = {}



------------------------------------------------------------
-- VARIABLES INTERNES
------------------------------------------------------------

obj.menuBar = nil

obj.enabledSpoons = nil



------------------------------------------------------------
-- LOG / NOTIFICATIONS
------------------------------------------------------------

function obj:log(message)

    print(
        string.format(
            "%s - SpoonManager %s - %s",
            os.date("%Y-%m-%d %H:%M:%S"),
            self.version,
            tostring(message)
        )
    )

end


function obj:notify(title, message)

    if not self.showNotifications then

        return

    end


    hs.notify.new({
        title = title,
        informativeText = message,
    }):send()

end



------------------------------------------------------------
-- CONFIGURATION
------------------------------------------------------------

function obj:registerSpoons(spoons)

    self.spoons =
        spoons or {}


    return self

end


function obj:loadEnabledSpoons()

    local stored =
        hs.settings.get(self.settingsKey)


    if type(stored) ~= "table" then

        stored =
            {}

    end


    self.enabledSpoons =
        {}


    for _, item in ipairs(self.spoons) do

        if stored[item.id] ~= nil then

            self.enabledSpoons[item.id] =
                stored[item.id] == true

        else

            self.enabledSpoons[item.id] =
                item.defaultEnabled ~= false

        end

    end


    return self

end


function obj:saveEnabledSpoons()

    hs.settings.set(
        self.settingsKey,
        self.enabledSpoons or {}
    )


    return self

end


function obj:isEnabled(item)

    if not self.enabledSpoons then

        self:loadEnabledSpoons()

    end


    return self.enabledSpoons[item.id] == true

end



------------------------------------------------------------
-- ACTIONS SPOONS
------------------------------------------------------------

function obj:runAction(item, actionName)

    local action =
        item[actionName]


    if type(action) ~= "function" then

        return true

    end


    local ok,
          err =
        pcall(action)


    if not ok then

        self:log(
            "Erreur "
            .. tostring(actionName)
            .. " "
            .. tostring(item.id)
            .. " : "
            .. tostring(err)
        )


        self:notify(
            "SpoonManager",
            "Erreur " .. tostring(item.label or item.id)
        )


        return false

    end


    return true

end


function obj:startManagedSpoon(item)

    if self:runAction(item, "start") then

        self:log(
            "Spoon active : "
            .. tostring(item.id)
        )


        return true

    end


    return false

end


function obj:stopManagedSpoon(item)

    if self:runAction(item, "stop") then

        self:log(
            "Spoon desactive : "
            .. tostring(item.id)
        )


        return true

    end


    return false

end


function obj:setSpoonEnabled(item, enabled)

    if not self.enabledSpoons then

        self:loadEnabledSpoons()

    end


    local ok =
        false


    if enabled then

        ok =
            self:startManagedSpoon(item)

    else

        ok =
            self:stopManagedSpoon(item)

    end


    if ok then

        self.enabledSpoons[item.id] =
            enabled == true


        self:saveEnabledSpoons()

    end


    self:updateMenuBar()


    return self

end


function obj:toggleSpoon(item)

    return self:setSpoonEnabled(
        item,
        not self:isEnabled(item)
    )

end


function obj:startEnabledSpoons()

    self:loadEnabledSpoons()


    for _, item in ipairs(self.spoons) do

        if self:isEnabled(item) then

            self:startManagedSpoon(item)

        end

    end


    return self

end



------------------------------------------------------------
-- HAMMERSPOON
------------------------------------------------------------

function obj:quitHammerspoon()

    local application =
        hs.application.get("Hammerspoon")


    if application then

        application:kill()

        return

    end


    hs.execute(
        "/usr/bin/osascript -e 'quit app \"Hammerspoon\"'"
    )

end



------------------------------------------------------------
-- MENU
------------------------------------------------------------

function obj:buildMenu()

    local menu =
        {}


    table.insert(
        menu,
        {
            title = "Spoons",
            disabled = true,
        }
    )


    for _, item in ipairs(self.spoons) do

        table.insert(
            menu,
            {
                title = item.label or item.id,
                checked = self:isEnabled(item),
                fn = function()

                    self:toggleSpoon(item)

                end,
            }
        )

    end


    table.insert(
        menu,
        {
            title = "-",
        }
    )


    table.insert(
        menu,
        {
            title = "Ouvrir la console",
            fn = function()

                hs.openConsole()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Recharger Hammerspoon",
            fn = function()

                hs.reload()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Quitter Hammerspoon",
            fn = function()

                self:quitHammerspoon()

            end,
        }
    )


    return menu

end


function obj:updateMenuBar()

    if not self.menuBar then

        return self

    end


    self.menuBar:setTitle(
        self.menuTitle
    )


    self.menuBar:setMenu(
        function()

            return self:buildMenu()

        end
    )


    return self

end


function obj:createMenuBar()

    if self.menuBar then

        return self:updateMenuBar()

    end


    self.menuBar =
        hs.menubar.new()


    if not self.menuBar then

        self:log(
            "ERREUR creation menubar"
        )


        return self

    end


    return self:updateMenuBar()

end



------------------------------------------------------------
-- START / STOP
------------------------------------------------------------

function obj:start()

    self:createMenuBar()

    self:startEnabledSpoons()

    self:updateMenuBar()

    self:log(
        "Spoon initialise"
    )


    return self

end


function obj:stop()

    if self.menuBar then

        self.menuBar:delete()

        self.menuBar =
            nil

    end


    return self

end


return obj
