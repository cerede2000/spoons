------------------------------------------------------------
--
-- ActivityKeeper Spoon
--
-- Version : 4.7.0
--
------------------------------------------------------------
--
-- OBJECTIF
--
-- Maintien de présence avec trois moteurs indépendants :
--
--   - UserActivity
--   - Clavier F20
--   - Souris
--
-- Réduction optionnelle de consommation :
--
--   - extinction rétroéclairage clavier
--   - diminution luminosité écran
--   - activation temporaire Low Power Mode
--
------------------------------------------------------------
--
-- ÉTATS
--
--   ●AK gris
--       ActivityKeeper OFF
--
--   ●AK jaune
--       surveillance de l'activité utilisateur
--
--   ●AK vert
--       maintien actif
--
------------------------------------------------------------
--
-- OUTILS EXTERNES OPTIONNELS
--
------------------------------------------------------------
--
-- 1. mac-brightnessctl
--
-- Permet :
--
--   - lecture précise du rétroéclairage clavier
--   - extinction à 0
--   - restauration précise de la valeur capturée
--
-- Chemins recherchés automatiquement :
--
--   /opt/homebrew/bin/mac-brightnessctl
--   /usr/local/bin/mac-brightnessctl
--   /opt/local/bin/mac-brightnessctl
--
-- Test :
--
--   /opt/homebrew/bin/mac-brightnessctl
--
-- Exemple :
--
--   Current brightness: 0.18
--
-- Sans cet outil :
--
--   fallback sur ILLUMINATION_TOGGLE via Hammerspoon.
--
-- Le fallback ne peut pas garantir une restauration
-- numérique précise de la valeur initiale.
--
------------------------------------------------------------
--
-- COMMANDES SYSTÈME NATIVES UTILISÉES
--
------------------------------------------------------------
--
-- /usr/bin/pmset
--
-- Utilisé pour :
--
--   - lire lowpowermode
--   - activer temporairement le mode économie d'énergie
--   - restaurer uniquement les profils modifiés
--
-- Lecture :
--
--   /usr/bin/pmset -g custom
--
-- Vérification rapide :
--
--   /usr/bin/pmset -g | grep lowpowermode
--
------------------------------------------------------------
--
-- SUDOERS NÉCESSAIRE UNIQUEMENT POUR LOW POWER MODE
--
------------------------------------------------------------
--
-- Créer :
--
--   sudo visudo -f /etc/sudoers.d/hammerspoon-pmset
--
-- Ajouter pour l'utilisateur benjy :
--
-- benjy ALL=(root) NOPASSWD: /usr/bin/pmset -b lowpowermode 0
-- benjy ALL=(root) NOPASSWD: /usr/bin/pmset -b lowpowermode 1
-- benjy ALL=(root) NOPASSWD: /usr/bin/pmset -c lowpowermode 0
-- benjy ALL=(root) NOPASSWD: /usr/bin/pmset -c lowpowermode 1
--
-- Vérification :
--
--   sudo -n /usr/bin/pmset -b lowpowermode 1
--
-- Puis retour éventuel :
--
--   sudo -n /usr/bin/pmset -b lowpowermode 0
--
------------------------------------------------------------
--
-- AUCUN SUDO NÉCESSAIRE POUR :
--
--   - F20
--   - UserActivity
--   - mouvement souris
--   - hs.screen:getBrightness()
--   - hs.screen:setBrightness()
--   - mac-brightnessctl
--
------------------------------------------------------------



------------------------------------------------------------
-- OBJET SPOON
------------------------------------------------------------

local obj = {}

obj.__index = obj



------------------------------------------------------------
-- MÉTADONNÉES
------------------------------------------------------------

obj.name = "ActivityKeeper"

obj.version = "4.7.6"

obj.author = "Benjamin Cerede / OpenAI"

obj.homepage = "Local Spoon"

obj.license = "MIT"



------------------------------------------------------------
-- CONFIGURATION PUBLIQUE
------------------------------------------------------------


------------------------------------------------------------
-- TEMPORISATIONS
------------------------------------------------------------

obj.idleThreshold = 120

obj.checkInterval = 5

obj.keepAliveInterval = 45

obj.doubleClickInterval = 0.30

obj.trackHighFrequencyPointerEvents = false

obj.fastReturnWatcherEnabled = true

obj.fastReturnThrottle = 0.20

obj.realActivityReturnIdleThreshold = 6

obj.postKeepAliveIdleIgnorePeriod = 8



------------------------------------------------------------
-- CLAVIER
------------------------------------------------------------

obj.activityKey = "f20"

obj.keyPressDuration = 0.05

obj.keyboardBacklightEnforceAfterKeepAlive = true

obj.keyboardBacklightEnforceDelay = 0.20

obj.keepAliveAfterEnergySavingDelay = 1.0

obj.keyboardBrightnessRestoreFallback = 0.50

obj.keyboardAutoRestoreConfirmDelay = 0.25



------------------------------------------------------------
-- SOURIS
------------------------------------------------------------

obj.mouseMovePixels = 1

obj.mouseReturnDelay = 0.15



------------------------------------------------------------
-- FILTRAGE ÉVÉNEMENTS SYNTHÉTIQUES
------------------------------------------------------------

obj.syntheticEventGracePeriod = 1.0



------------------------------------------------------------
-- PROBE BACKLIGHT
------------------------------------------------------------

obj.keyboardBacklightProbeDelay = 0.75

obj.keyboardBacklightProbeRetries = 4

obj.keyboardBacklightProbeRetryInterval = 0.25

obj.keyboardBrightnessSampleInterval = 300



------------------------------------------------------------
-- VALEURS PAR DÉFAUT
------------------------------------------------------------

obj.defaultUserActivityEnabled = false

obj.defaultKeyboardEnabled = true

obj.defaultMouseEnabled = false

obj.defaultKeyboardBacklightEnabled = true

obj.defaultScreenDimmingEnabled = false

obj.defaultLowPowerModeEnabled = false

obj.forceConfiguredModesOnStart = false



------------------------------------------------------------
-- LUMINOSITÉ ÉCRAN CIBLE
--
-- 0.15 = 15 %
------------------------------------------------------------

obj.screenBrightnessTarget = 0.15



------------------------------------------------------------
-- INTERFACE
------------------------------------------------------------

obj.showStateNotifications = true

obj.verboseLogging = false



------------------------------------------------------------
-- OUTILS
------------------------------------------------------------

obj.keyboardBrightnessToolPaths = {

    "/opt/homebrew/bin/mac-brightnessctl",

    "/usr/local/bin/mac-brightnessctl",

    "/opt/local/bin/mac-brightnessctl"

}


obj.pmsetPath = "/usr/bin/pmset"

obj.sudoPath = "/usr/bin/sudo"



------------------------------------------------------------
-- SETTINGS PERSISTANTS
------------------------------------------------------------

obj.SETTING_KEYS = {

    USER_ACTIVITY =
        "ActivityKeeper.mode.userActivity",

    KEYBOARD =
        "ActivityKeeper.mode.keyboard",

    MOUSE =
        "ActivityKeeper.mode.mouse",

    KEYBOARD_BACKLIGHT =
        "ActivityKeeper.energy.keyboardBacklight",

    SCREEN_DIMMING =
        "ActivityKeeper.energy.screenDimming",

    LOW_POWER =
        "ActivityKeeper.energy.lowPowerMode"

}



------------------------------------------------------------
-- ÉTATS
------------------------------------------------------------

obj.STATE = {

    OFF =
        "OFF",

    MONITORING =
        "MONITORING",

    KEEPALIVE =
        "KEEPALIVE"

}



------------------------------------------------------------
-- VARIABLES GÉNÉRALES
------------------------------------------------------------

obj.currentState =
    obj.STATE.OFF


obj.checkTimer =
    nil


obj.returnMouseTimer =
    nil


obj.keyUpTimer =
    nil


obj.inputWatcher =
    nil


obj.fastReturnWatcher =
    nil


obj.menuBar =
    nil


obj.hotkeys =
    {}


obj.clickCount =
    0


obj.clickTimer =
    nil



------------------------------------------------------------
-- KEEPALIVE
------------------------------------------------------------

obj.lastKeepAliveTime =
    nil


obj.lastRealActivityTime =
    nil


obj.lastFastReturnEventAt =
    0


obj.keepAliveCount =
    0


obj.keepAliveInProgress =
    false


obj.userActivityAssertionId =
    nil


obj.syntheticEventIgnoreUntil =
    0



------------------------------------------------------------
-- BACKLIGHT CLAVIER
------------------------------------------------------------

obj.keyboardBrightnessTool =
    nil


obj.keyboardBrightnessBackend =
    "fallback"


obj.lastKnownNonZeroKeyboardBrightness =
    nil


obj.savedKeyboardBrightness =
    nil


obj.keyboardBacklightModified =
    false


obj.savedKeyboardAutoBrightness =
    nil


obj.keyboardAutoBrightnessModified =
    false


obj.keyboardBacklightProbeTimer =
    nil


obj.keyboardBacklightProbeRetryTimer =
    nil


obj.keyboardBacklightEnforceTimer =
    nil


obj.initialKeepAliveTimer =
    nil


obj.keyboardAutoRestoreTimer =
    nil


obj.lastKeyboardBrightnessSampleAt =
    nil



------------------------------------------------------------
-- ÉCRAN
------------------------------------------------------------

obj.savedScreenBrightness =
    nil


obj.savedScreenId =
    nil


obj.screenBrightnessModified =
    false



------------------------------------------------------------
-- LOW POWER MODE
------------------------------------------------------------

obj.savedLowPowerBattery =
    nil


obj.savedLowPowerAC =
    nil


obj.lowPowerBatteryModified =
    false


obj.lowPowerACModified =
    false



------------------------------------------------------------
-- LOG
------------------------------------------------------------

function obj:log(message)

    print(

        string.format(

            "%s - ActivityKeeper %s - %s",

            os.date(
                "%Y-%m-%d %H:%M:%S"
            ),

            self.version,

            tostring(message)

        )

    )

end



------------------------------------------------------------
-- TEMPS HAUTE PRÉCISION
------------------------------------------------------------

function obj:now()

    return hs.timer.secondsSinceEpoch()

end



------------------------------------------------------------
-- FORMAT DURÉE
------------------------------------------------------------

function obj:formatDuration(seconds)

    seconds =
        math.floor(
            seconds or 0
        )


    if seconds < 60 then

        return string.format(
            "%d sec",
            seconds
        )

    end


    if seconds < 3600 then

        return string.format(

            "%d min %02d sec",

            math.floor(
                seconds / 60
            ),

            seconds % 60

        )

    end


    return string.format(

        "%d h %02d min",

        math.floor(
            seconds / 3600
        ),

        math.floor(

            (seconds % 3600)
            /
            60

        )

    )

end



------------------------------------------------------------
-- SETTINGS BOOLÉENS
------------------------------------------------------------

function obj:getBooleanSetting(
    key,
    defaultValue
)

    local value =
        hs.settings.get(key)


    if value == nil then

        return defaultValue == true

    end


    return value == true

end



function obj:setBooleanSetting(
    key,
    value,
    label
)

    hs.settings.set(

        key,

        value == true

    )


    self:log(

        string.format(

            "%s : %s",

            label,

            value
                and "ON"
                or "OFF"

        )

    )


    hs.alert.show(

        (
            value
            and "✓ "
            or "✕ "
        )
        ..
        label

    )


    return value

end


function obj:applyConfiguredModeDefaults()

    if not self.forceConfiguredModesOnStart then

        return self

    end


    hs.settings.set(
        self.SETTING_KEYS.USER_ACTIVITY,
        self.defaultUserActivityEnabled == true
    )


    hs.settings.set(
        self.SETTING_KEYS.KEYBOARD,
        self.defaultKeyboardEnabled == true
    )


    hs.settings.set(
        self.SETTING_KEYS.MOUSE,
        self.defaultMouseEnabled == true
    )


    return self

end



------------------------------------------------------------
-- LECTURE DES MODES
------------------------------------------------------------

function obj:isUserActivityEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.USER_ACTIVITY,

        self.defaultUserActivityEnabled

    )

end



function obj:isKeyboardEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.KEYBOARD,

        self.defaultKeyboardEnabled

    )

end



function obj:isMouseEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.MOUSE,

        self.defaultMouseEnabled

    )

end



function obj:isKeyboardBacklightEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.KEYBOARD_BACKLIGHT,

        self.defaultKeyboardBacklightEnabled

    )

end



function obj:isScreenDimmingEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.SCREEN_DIMMING,

        self.defaultScreenDimmingEnabled

    )

end



function obj:isLowPowerModeEnabled()

    return self:getBooleanSetting(

        self.SETTING_KEYS.LOW_POWER,

        self.defaultLowPowerModeEnabled

    )

end



------------------------------------------------------------
-- IDLE MACOS
------------------------------------------------------------

function obj:getIdleTime()

    local success,
          result =

        pcall(
            hs.host.idleTime
        )


    if not success then

        self:log(
            "ERREUR hs.host.idleTime()"
        )


        return 0

    end


    return result or 0

end



------------------------------------------------------------
-- LABEL ÉTAT
------------------------------------------------------------

function obj:getStateLabel()

    if self.currentState == self.STATE.OFF then

        return "Désactivé"

    end


    if self.currentState == self.STATE.MONITORING then

        return "Surveillance active"

    end


    if self.currentState == self.STATE.KEEPALIVE then

        return "Maintien actif"

    end


    return "Inconnu"

end



------------------------------------------------------------
-- ICÔNE MENUBAR COMPACTE
--
-- ●AK gris
-- ●AK jaune
-- ●AK vert
------------------------------------------------------------

function obj:updateMenuBar()

    if not self.menuBar then

        return

    end


    local color

    local tooltip


    --------------------------------------------------------
    -- OFF
    --------------------------------------------------------

    if self.currentState == self.STATE.OFF then

        color = {

            red = 0.55,

            green = 0.55,

            blue = 0.55,

            alpha = 1.0

        }


        tooltip =
            "Activity Keeper désactivé"


    --------------------------------------------------------
    -- MONITORING
    --------------------------------------------------------

    elseif self.currentState == self.STATE.MONITORING then

        color = {

            red = 1.0,

            green = 0.75,

            blue = 0.0,

            alpha = 1.0

        }


        tooltip =
            "Activity Keeper actif - surveillance"


    --------------------------------------------------------
    -- KEEPALIVE
    --------------------------------------------------------

    elseif self.currentState == self.STATE.KEEPALIVE then

        color = {

            red = 0.15,

            green = 0.75,

            blue = 0.25,

            alpha = 1.0

        }


        tooltip =
            "Activity Keeper - maintien actif"


    --------------------------------------------------------
    -- INCONNU
    --------------------------------------------------------

    else

        color = {

            red = 0.55,

            green = 0.55,

            blue = 0.55,

            alpha = 1.0

        }


        tooltip =
            "Activity Keeper - état inconnu"

    end


    self.menuBar:setTitle(

        hs.styledtext.new(

            "●AK",

            {
                color = color
            }

        )

    )


    self.menuBar:setTooltip(
        tooltip
    )

end



------------------------------------------------------------
-- CHANGEMENT D'ÉTAT
------------------------------------------------------------

function obj:setState(newState)

    if self.currentState == newState then

        self:updateMenuBar()

        return

    end


    local oldState =
        self.currentState


    self.currentState =
        newState


    if newState == self.STATE.KEEPALIVE then

        self:startFastReturnWatcher()

    else

        self:stopFastReturnWatcher()

    end


    self:updateMenuBar()


    self:log(

        string.format(

            "État : %s -> %s",

            oldState,

            newState

        )

    )


    if not self.showStateNotifications then

        return

    end


    if newState == self.STATE.MONITORING then

        hs.alert.show(
            "Activity Keeper : surveillance"
        )


    elseif newState == self.STATE.KEEPALIVE then

        hs.alert.show(
            "Activity Keeper : maintien actif"
        )


    elseif newState == self.STATE.OFF then

        hs.alert.show(
            "Activity Keeper : OFF"
        )

    end

end



------------------------------------------------------------
-- FENÊTRE ANTI-DÉTECTION ÉVÉNEMENTS SYNTHÉTIQUES
------------------------------------------------------------

function obj:isSyntheticEventWindow()

    return

        self:now()
        <=
        self.syntheticEventIgnoreUntil

end



function obj:openSyntheticEventWindow()

    self.syntheticEventIgnoreUntil =

        self:now()
        +
        self.syntheticEventGracePeriod

end



------------------------------------------------------------
-- ACTIVITÉ UTILISATEUR RÉELLE
------------------------------------------------------------

function obj:handleRealUserActivity()

    if self.currentState == self.STATE.OFF then

        return

    end


    if self:isSyntheticEventWindow() then

        return

    end


    self.lastRealActivityTime =
        os.time()


    --------------------------------------------------------
    -- Actualisation référence clavier
    --------------------------------------------------------

    self:sampleKeyboardBrightness(false)


    --------------------------------------------------------
    -- VERT -> JAUNE
    --------------------------------------------------------

    if self.currentState == self.STATE.KEEPALIVE then

        self:log(
            "Activité utilisateur réelle détectée"
        )


        ----------------------------------------------------
        -- Restaurer les états énergétiques
        ----------------------------------------------------

        self:restoreEnergySavingState()


        ----------------------------------------------------
        -- Retour monitoring
        ----------------------------------------------------

        self:setState(
            self.STATE.MONITORING
        )

    end

end



------------------------------------------------------------
-- WATCHER D'ACTIVITÉ RÉELLE
------------------------------------------------------------

function obj:createInputWatcher()

    if self.inputWatcher then

        return

    end


    local eventTypes = {

        hs.eventtap.event.types.keyDown,

        hs.eventtap.event.types.flagsChanged,

        hs.eventtap.event.types.leftMouseDown,

        hs.eventtap.event.types.rightMouseDown,

        hs.eventtap.event.types.otherMouseDown,

        hs.eventtap.event.types.scrollWheel

    }


    if self.trackHighFrequencyPointerEvents then

        table.insert(
            eventTypes,
            hs.eventtap.event.types.mouseMoved
        )


        table.insert(
            eventTypes,
            hs.eventtap.event.types.leftMouseDragged
        )


        table.insert(
            eventTypes,
            hs.eventtap.event.types.rightMouseDragged
        )


        table.insert(
            eventTypes,
            hs.eventtap.event.types.otherMouseDragged
        )

    end


    self.inputWatcher =

        hs.eventtap.new(

            eventTypes,

            function()

                if self.currentState == self.STATE.OFF then

                    return false

                end


                if self.currentState == self.STATE.KEEPALIVE
                    and self.fastReturnWatcherEnabled then


                    return false

                end


                if self:isSyntheticEventWindow() then

                    return false

                end


                self:handleRealUserActivity()


                return false

            end

        )

end



------------------------------------------------------------
-- WATCHER RAPIDE DE RETOUR UTILISATEUR
--
-- Actif uniquement en KEEPALIVE pour retrouver une reprise
-- immédiate sans ralentir le mode MONITORING.
------------------------------------------------------------

function obj:createFastReturnWatcher()

    if self.fastReturnWatcher then

        return

    end


    local eventTypes = {

        hs.eventtap.event.types.keyDown,

        hs.eventtap.event.types.flagsChanged,

        hs.eventtap.event.types.leftMouseDown,

        hs.eventtap.event.types.rightMouseDown,

        hs.eventtap.event.types.otherMouseDown,

        hs.eventtap.event.types.mouseMoved,

        hs.eventtap.event.types.leftMouseDragged,

        hs.eventtap.event.types.rightMouseDragged,

        hs.eventtap.event.types.otherMouseDragged,

        hs.eventtap.event.types.scrollWheel

    }


    self.fastReturnWatcher =

        hs.eventtap.new(

            eventTypes,

            function()

                if self.currentState
                    ~= self.STATE.KEEPALIVE then


                    return false

                end


                if self:isSyntheticEventWindow() then

                    return false

                end


                local now =
                    self:now()


                if now - self.lastFastReturnEventAt
                    < self.fastReturnThrottle then


                    return false

                end


                self.lastFastReturnEventAt =
                    now


                self:handleRealUserActivity()


                return false

            end

        )

end


function obj:startFastReturnWatcher()

    if not self.fastReturnWatcherEnabled then

        return

    end


    self:createFastReturnWatcher()


    if self.fastReturnWatcher then

        self.fastReturnWatcher:start()

    end

end


function obj:stopFastReturnWatcher()

    if self.fastReturnWatcher then

        self.fastReturnWatcher:stop()

    end

end



------------------------------------------------------------
-- USER ACTIVITY
------------------------------------------------------------

function obj:sendUserActivity()

    if not self:isUserActivityEnabled() then

        return false

    end


    local success,
          errorMessage =

        pcall(

            function()

                self.userActivityAssertionId =

                    hs.caffeinate.declareUserActivity(

                        self.userActivityAssertionId

                    )

            end

        )


    if not success then

        self:log(

            "ERREUR UserActivity : "
            ..
            tostring(errorMessage)

        )


        return false

    end


    return true

end



------------------------------------------------------------
-- F20 SYNTHÉTIQUE
------------------------------------------------------------

function obj:postF20()

    self:openSyntheticEventWindow()


    local success,
          errorMessage =

        pcall(

            function()

                ------------------------------------------------
                -- DOWN
                ------------------------------------------------

                hs.eventtap.event.newKeyEvent(

                    {},

                    self.activityKey,

                    true

                ):post()


                ------------------------------------------------
                -- UP différé
                ------------------------------------------------

                self.keyUpTimer =

                    hs.timer.doAfter(

                        self.keyPressDuration,

                        function()

                            hs.eventtap.event.newKeyEvent(

                                {},

                                self.activityKey,

                                false

                            ):post()

                        end

                    )

            end

        )


    if not success then

        self:log(

            "ERREUR F20 : "
            ..
            tostring(errorMessage)

        )


        return false

    end


    return true

end



------------------------------------------------------------
-- ACTIVITÉ CLAVIER
------------------------------------------------------------

function obj:sendKeyboardActivity()

    if not self:isKeyboardEnabled() then

        return false

    end


    return self:postF20()

end



------------------------------------------------------------
-- ACTIVITÉ SOURIS
------------------------------------------------------------

function obj:sendMouseActivity()

    if not self:isMouseEnabled() then

        return false

    end


    self:openSyntheticEventWindow()


    local originalPosition =
        hs.mouse.absolutePosition()


    if not originalPosition then

        self:log(
            "Position souris inaccessible"
        )


        return false

    end


    local temporaryPosition = {

        x =
            originalPosition.x
            +
            self.mouseMovePixels,

        y =
            originalPosition.y

    }


    local success,
          errorMessage =

        pcall(

            function()

                ------------------------------------------------
                -- Aller
                ------------------------------------------------

                hs.eventtap.event.newMouseEvent(

                    hs.eventtap.event.types.mouseMoved,

                    temporaryPosition

                ):post()


                hs.mouse.absolutePosition(
                    temporaryPosition
                )


                ------------------------------------------------
                -- Retour
                ------------------------------------------------

                self.returnMouseTimer =

                    hs.timer.doAfter(

                        self.mouseReturnDelay,

                        function()

                            hs.eventtap.event.newMouseEvent(

                                hs.eventtap.event.types.mouseMoved,

                                originalPosition

                            ):post()


                            hs.mouse.absolutePosition(
                                originalPosition
                            )

                        end

                    )

            end

        )


    if not success then

        self:log(

            "ERREUR souris : "
            ..
            tostring(errorMessage)

        )


        return false

    end


    return true

end



------------------------------------------------------------
-- DÉTECTION MAC-BRIGHTNESSCTL
------------------------------------------------------------

function obj:detectKeyboardBrightnessTool()

    self.keyboardBrightnessTool =
        nil


    self.keyboardBrightnessBackend =
        "fallback"


    for _, path
        in ipairs(self.keyboardBrightnessToolPaths) do


        local attributes =
            hs.fs.attributes(path)


        if attributes
            and attributes.mode == "file" then


            self.keyboardBrightnessTool =
                path


            self.keyboardBrightnessBackend =
                "mac-brightnessctl"


            self:log(

                "Backend backlight précis : "
                ..
                path

            )


            return path

        end

    end


    self:log(
        "Backend backlight : fallback Hammerspoon"
    )


    return nil

end



------------------------------------------------------------
-- LABEL BACKEND
------------------------------------------------------------

function obj:getKeyboardBacklightBackendLabel()

    if self.keyboardBrightnessBackend
        == "mac-brightnessctl" then


        return "mac-brightnessctl"

    end


    return "Hammerspoon fallback"

end



------------------------------------------------------------
-- EXÉCUTION MAC-BRIGHTNESSCTL
------------------------------------------------------------

function obj:runBrightnessTool(argument)

    if not self.keyboardBrightnessTool then

        return nil,
            false

    end


    local command =

        string.format(

            "%q",

            self.keyboardBrightnessTool

        )


    if argument ~= nil then

        command =
            command
            ..
            " "
            ..
            tostring(argument)

    end


    local output,
          success,
          terminationType,
          returnCode =

        hs.execute(

            command,

            true

        )


    if not success then

        self:log(

            "ERREUR mac-brightnessctl : "
            ..
            tostring(terminationType)
            ..
            " / "
            ..
            tostring(returnCode)
            ..
            " / "
            ..
            tostring(output)

        )

    end


    return output,
        success

end



------------------------------------------------------------
-- LECTURE BACKLIGHT CLAVIER
------------------------------------------------------------

function obj:getKeyboardBrightness()

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return nil

    end


    local output,
          success =

        self:runBrightnessTool(nil)


    if not success then

        return nil

    end


    --------------------------------------------------------
    -- Parse explicite :
    --
    -- Current brightness: 0.19
    --------------------------------------------------------

    local valueString =

        tostring(output):match(

            "Current%s+brightness:%s*([0-9]+%.?[0-9]*)"

        )


    if not valueString then

        self:log(

            "Sortie brightness non reconnue : "
            ..
            tostring(output)

        )


        return nil

    end


    return tonumber(
        valueString
    )

end



------------------------------------------------------------
-- MÉMORISER UNE VALEUR NON NULLE
------------------------------------------------------------

function obj:sampleKeyboardBrightness(force)

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return

    end


    local now =
        self:now()


    if force ~= true
        and self.lastKeyboardBrightnessSampleAt
        and now - self.lastKeyboardBrightnessSampleAt
            < self.keyboardBrightnessSampleInterval then


        return

    end


    self.lastKeyboardBrightnessSampleAt =
        now


    local value =
        self:getKeyboardBrightness()


    if value
        and value > 0.01 then


        self.lastKnownNonZeroKeyboardBrightness =
            value


        if self.verboseLogging then

            self:log(

                string.format(

                    "Référence clavier : %.4f",

                    value

                )

            )

        end

    end

end



------------------------------------------------------------
-- FIXER BACKLIGHT CLAVIER
------------------------------------------------------------

function obj:setKeyboardBrightness(value)

    value =
        tonumber(value)


    if value == nil then

        return false

    end


    value =

        math.max(

            0,

            math.min(
                1,
                value
            )

        )


    local _,
          success =

        self:runBrightnessTool(

            string.format(
                "%.4f",
                value
            )

        )


    return success

end


------------------------------------------------------------
-- AUTO-BRIGHTNESS CLAVIER
------------------------------------------------------------

function obj:getKeyboardAutoBrightness()

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return nil

    end


    local output,
          success =

        self:runBrightnessTool("-a")


    if not success then

        return nil

    end


    output =
        tostring(output or "")


    if output:match("Enabled") then

        return true

    end


    if output:match("Disabled") then

        return false

    end


    self:log(

        "Sortie auto-brightness non reconnue : "
        ..
        output

    )


    return nil

end


function obj:setKeyboardAutoBrightness(enabled)

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return false

    end


    local _,
          success =

        self:runBrightnessTool(

            enabled
                and "-a 1"
                or "-a 0"

        )


    return success

end


function obj:disableKeyboardAutoBrightness()

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return false

    end


    if self.keyboardAutoBrightnessModified then

        return true

    end


    local current =
        self:getKeyboardAutoBrightness()


    self.savedKeyboardAutoBrightness =
        current


    if current ~= true then

        self:log(
            "Auto-brightness clavier déjà désactivé ou inconnu"
        )


        return false

    end


    if self:setKeyboardAutoBrightness(false) then

        self.keyboardAutoBrightnessModified =
            true


        self:log(
            "Auto-brightness clavier désactivé temporairement"
        )


        return true

    end


    self:log(
        "Échec désactivation auto-brightness clavier"
    )


    return false

end


function obj:restoreKeyboardAutoBrightness()

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return false

    end


    if not self.keyboardAutoBrightnessModified then

        self.savedKeyboardAutoBrightness =
            nil


        return false

    end


    if self.savedKeyboardAutoBrightness == true then

        if self:setKeyboardAutoBrightness(true) then

            self:log(
                "Auto-brightness clavier restauré"
            )


            self.keyboardAutoBrightnessModified =
                false


            self.savedKeyboardAutoBrightness =
                nil


            return true

        end


        self:log(
            "Échec restauration auto-brightness clavier"
        )


        return false

    end


    self.keyboardAutoBrightnessModified =
        false


    self.savedKeyboardAutoBrightness =
        nil


    return false

end


function obj:scheduleKeyboardAutoBrightnessRestoreConfirm()

    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return self

    end


    if self.keyboardAutoRestoreTimer then

        self.keyboardAutoRestoreTimer:stop()


        self.keyboardAutoRestoreTimer =
            nil

    end


    self.keyboardAutoRestoreTimer =

        hs.timer.doAfter(

            self.keyboardAutoRestoreConfirmDelay,

            function()

                self.keyboardAutoRestoreTimer =
                    nil


                if self.currentState
                    == self.STATE.KEEPALIVE then


                    return

                end


                self:setKeyboardAutoBrightness(true)

            end

        )


    return self

end



------------------------------------------------------------
-- TOUCHE SYSTÈME
------------------------------------------------------------

function obj:sendSystemKey(keyName)

    local success,
          errorMessage =

        pcall(

            function()

                hs.eventtap.event.newSystemKeyEvent(

                    keyName,

                    true

                ):post()


                hs.eventtap.event.newSystemKeyEvent(

                    keyName,

                    false

                ):post()

            end

        )


    if not success then

        self:log(

            "ERREUR touche système "
            ..
            tostring(keyName)
            ..
            " : "
            ..
            tostring(errorMessage)

        )

    end


    return success

end



------------------------------------------------------------
-- RÉVEIL DU CLAVIER AVANT CAPTURE
------------------------------------------------------------

function obj:wakeKeyboardForBacklightProbe()

    self:log(
        "Réveil clavier par F20 avant capture backlight"
    )


    return self:postF20()

end



------------------------------------------------------------
-- CAPTURE APRÈS RÉVEIL ET EXTINCTION
------------------------------------------------------------

function obj:captureAndDisableKeyboardBacklight(
    attempt
)

    attempt =
        attempt or 1


    --------------------------------------------------------
    -- L'utilisateur est revenu entre-temps
    --------------------------------------------------------

    if self.currentState
        ~= self.STATE.KEEPALIVE then


        self:log(
            "Probe backlight annulé : sortie KEEPALIVE"
        )


        return false

    end


    --------------------------------------------------------
    -- Lecture
    --------------------------------------------------------

    local current =
        self:getKeyboardBrightness()


    self:log(

        string.format(

            "Probe clavier %d/%d : %s",

            attempt,

            self.keyboardBacklightProbeRetries,

            current
                and string.format(
                    "%.4f",
                    current
                )
                or "lecture impossible"

        )

    )


    --------------------------------------------------------
    -- VALEUR VALIDE
    --------------------------------------------------------

    if current
        and current > 0.01 then


        self.savedKeyboardBrightness =
            current


        self.lastKnownNonZeroKeyboardBrightness =
            current


        self:log(

            string.format(

                "Valeur backlight capturée : %.4f",

                current

            )

        )


        if self:setKeyboardBrightness(0) then

            self.keyboardBacklightModified =
                true


            self:log(

                string.format(

                    "Clavier éteint ; restauration prévue : %.4f",

                    current

                )

            )


            return true

        end


        self:log(
            "Échec extinction backlight clavier"
        )


        return false

    end


    --------------------------------------------------------
    -- RETRY
    --------------------------------------------------------

    if attempt
        < self.keyboardBacklightProbeRetries then


        self.keyboardBacklightProbeRetryTimer =

            hs.timer.doAfter(

                self.keyboardBacklightProbeRetryInterval,

                function()

                    self.keyboardBacklightProbeRetryTimer =
                        nil


                    self:captureAndDisableKeyboardBacklight(

                        attempt + 1

                    )

                end

            )


        return true

    end


    --------------------------------------------------------
    -- FALLBACK DERNIÈRE BONNE VALEUR
    --------------------------------------------------------

    if self.lastKnownNonZeroKeyboardBrightness then

        self.savedKeyboardBrightness =
            self.lastKnownNonZeroKeyboardBrightness


        self:log(

            string.format(

                "Fallback référence précédente : %.4f",

                self.savedKeyboardBrightness

            )

        )


        if self:setKeyboardBrightness(0) then

            self.keyboardBacklightModified =
                true


            return true

        end

    end


    --------------------------------------------------------
    -- AUCUNE VALEUR FIABLE
    --
    -- On ne coupe pas le clavier pour éviter de ne pas
    -- savoir le restaurer correctement.
    --------------------------------------------------------

    self:log(

        "Aucune valeur backlight fiable ; "
        ..
        "extinction annulée"

    )


    return false

end



------------------------------------------------------------
-- DÉSACTIVER BACKLIGHT CLAVIER
------------------------------------------------------------

function obj:disableKeyboardBacklight()

    if not self:isKeyboardBacklightEnabled() then

        return false

    end


    if self.keyboardBacklightModified then

        return true

    end


    --------------------------------------------------------
    -- BACKEND PRÉCIS
    --------------------------------------------------------

    if self.keyboardBrightnessBackend
        == "mac-brightnessctl" then


        ----------------------------------------------------
        -- Nettoyage ancien probe
        ----------------------------------------------------

        if self.keyboardBacklightProbeTimer then

            self.keyboardBacklightProbeTimer:stop()


            self.keyboardBacklightProbeTimer =
                nil

        end


        if self.keyboardBacklightProbeRetryTimer then

            self.keyboardBacklightProbeRetryTimer:stop()


            self.keyboardBacklightProbeRetryTimer =
                nil

        end


        ----------------------------------------------------
        -- Capture directe sans réveiller le clavier.
        --
        -- Réveiller par F20 allume le rétroéclairage alors
        -- qu'on vient justement d'entrer en KEEPALIVE.
        ----------------------------------------------------

        return self:captureAndDisableKeyboardBacklight(
            1
        )

    end


    --------------------------------------------------------
    -- FALLBACK HAMMERSPOON
    --------------------------------------------------------

    local success =

        self:sendSystemKey(
            "ILLUMINATION_TOGGLE"
        )


    if success then

        self.keyboardBacklightModified =
            true


        self:log(
            "Backlight coupé via fallback toggle"
        )

    end


    return success

end


------------------------------------------------------------
-- FORCER BACKLIGHT À 0 APRÈS KEEPALIVE
------------------------------------------------------------

function obj:forceKeyboardBacklightOffAfterKeepAlive()

    if not self.keyboardBacklightEnforceAfterKeepAlive then

        return false

    end


    if not self:isKeyboardBacklightEnabled() then

        return false

    end


    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return false

    end


    if self.currentState
        ~= self.STATE.KEEPALIVE then


        return false

    end


    local current =
        self:getKeyboardBrightness()


    if current
        and current > 0.01
        and self.savedKeyboardBrightness == nil then


        self.savedKeyboardBrightness =
            current


        self.lastKnownNonZeroKeyboardBrightness =
            current

    end


    if self:setKeyboardBrightness(0) then

        self.keyboardBacklightModified =
            true


        if self.verboseLogging then

            self:log(
                "Backlight clavier forcé à 0 après keepalive"
            )

        end


        return true

    end


    self:log(
        "Échec forçage backlight clavier après keepalive"
    )


    return false

end


function obj:scheduleKeyboardBacklightEnforce()

    if not self.keyboardBacklightEnforceAfterKeepAlive then

        return self

    end


    if self.keyboardBrightnessBackend
        ~= "mac-brightnessctl" then


        return self

    end


    if self.keyboardBacklightEnforceTimer then

        self.keyboardBacklightEnforceTimer:stop()


        self.keyboardBacklightEnforceTimer =
            nil

    end


    self.keyboardBacklightEnforceTimer =

        hs.timer.doAfter(

            self.keyPressDuration
            +
            self.keyboardBacklightEnforceDelay,

            function()

                self.keyboardBacklightEnforceTimer =
                    nil


                self:forceKeyboardBacklightOffAfterKeepAlive()

            end

        )


    return self

end



------------------------------------------------------------
-- RESTAURER BACKLIGHT CLAVIER
------------------------------------------------------------

function obj:restoreKeyboardBacklight(force)

    --------------------------------------------------------
    -- Annuler probe en attente
    --------------------------------------------------------

    if self.keyboardBacklightProbeTimer then

        self.keyboardBacklightProbeTimer:stop()


        self.keyboardBacklightProbeTimer =
            nil

    end


    if self.keyboardBacklightProbeRetryTimer then

        self.keyboardBacklightProbeRetryTimer:stop()


        self.keyboardBacklightProbeRetryTimer =
            nil

    end


    --------------------------------------------------------
    -- Rien à restaurer
    --------------------------------------------------------

    if not self.keyboardBacklightModified
        and force ~= true then

        return false

    end


    --------------------------------------------------------
    -- RESTAURATION PRÉCISE
    --------------------------------------------------------

    if self.keyboardBrightnessBackend
        == "mac-brightnessctl" then


        local value =
            self.savedKeyboardBrightness
            or self.lastKnownNonZeroKeyboardBrightness
            or self.keyboardBrightnessRestoreFallback


        if self:setKeyboardBrightness(value) then

            self:log(

                string.format(

                    "Clavier restauré : %.4f",

                    value

                )

            )


            self.lastKnownNonZeroKeyboardBrightness =
                value


            self.savedKeyboardBrightness =
                nil


            self.keyboardBacklightModified =
                false


            return true

        end


        self:log(
            "Échec restauration précise clavier"
        )


        return false

    end


    --------------------------------------------------------
    -- FALLBACK TOGGLE
    --------------------------------------------------------

    local success =

        self:sendSystemKey(
            "ILLUMINATION_TOGGLE"
        )


    if success then

        self.savedKeyboardBrightness =
            nil


        self.keyboardBacklightModified =
            false


        self:log(
            "Clavier restauré via fallback toggle"
        )

    end


    return success

end



------------------------------------------------------------
-- RÉDUCTION LUMINOSITÉ ÉCRAN
------------------------------------------------------------

function obj:dimScreen()

    if not self:isScreenDimmingEnabled() then

        return false

    end


    if self.screenBrightnessModified then

        return true

    end


    local screen =
        hs.screen.mainScreen()


    if not screen then

        self:log(
            "Écran principal introuvable"
        )


        return false

    end


    local current =
        screen:getBrightness()


    if current == nil then

        self:log(
            "Lecture luminosité écran non supportée"
        )


        return false

    end


    --------------------------------------------------------
    -- L'écran est déjà plus sombre que la cible.
    --
    -- Ne pas l'augmenter.
    --------------------------------------------------------

    if current <= self.screenBrightnessTarget then

        self:log(

            string.format(

                "Écran déjà <= cible : %.4f",

                current

            )

        )


        return false

    end


    self.savedScreenBrightness =
        current


    self.savedScreenId =
        screen:id()


    screen:setBrightness(
        self.screenBrightnessTarget
    )


    self.screenBrightnessModified =
        true


    self:log(

        string.format(

            "Écran %.4f -> %.4f",

            current,

            self.screenBrightnessTarget

        )

    )


    return true

end



------------------------------------------------------------
-- RESTAURER LUMINOSITÉ ÉCRAN
------------------------------------------------------------

function obj:restoreScreen()

    if not self.screenBrightnessModified then

        return false

    end


    local screen =
        nil


    --------------------------------------------------------
    -- Retrouver l'écran sauvegardé
    --------------------------------------------------------

    if self.savedScreenId then

        for _, candidate
            in ipairs(
                hs.screen.allScreens()
            ) do


            if candidate:id()
                == self.savedScreenId then


                screen =
                    candidate


                break

            end

        end

    end


    --------------------------------------------------------
    -- Fallback écran principal actuel
    --------------------------------------------------------

    if not screen then

        screen =
            hs.screen.mainScreen()

    end


    if not screen
        or self.savedScreenBrightness == nil then


        self:log(
            "Impossible de restaurer l'écran"
        )


        return false

    end


    screen:setBrightness(
        self.savedScreenBrightness
    )


    self:log(

        string.format(

            "Écran restauré : %.4f",

            self.savedScreenBrightness

        )

    )


    self.savedScreenBrightness =
        nil


    self.savedScreenId =
        nil


    self.screenBrightnessModified =
        false


    return true

end



------------------------------------------------------------
-- LIRE LES PROFILS LOW POWER MODE
--
-- Retour :
--
--   battery
--   ac
------------------------------------------------------------

function obj:getLowPowerStates()

    local output,
          success,
          terminationType,
          returnCode =

        hs.execute(

            string.format(

                "%q -g custom",

                self.pmsetPath

            ),

            true

        )


    if not success then

        self:log(

            "ERREUR lecture pmset : "
            ..
            tostring(terminationType)
            ..
            " / "
            ..
            tostring(returnCode)

        )


        return nil,
            nil

    end


    local section =
        nil


    local battery =
        nil


    local ac =
        nil


    for line
        in tostring(output):gmatch(
            "[^\r\n]+"
        ) do


        ----------------------------------------------------
        -- Sections
        ----------------------------------------------------

        if line:match(
            "^Battery Power:"
        ) then


            section =
                "battery"


        elseif line:match(
            "^AC Power:"
        ) then


            section =
                "ac"


        else

            ------------------------------------------------
            -- lowpowermode N
            ------------------------------------------------

            local value =

                line:match(

                    "^%s*lowpowermode%s+(%d+)"

                )


            if value then

                value =
                    tonumber(value)


                if section == "battery" then

                    battery =
                        value


                elseif section == "ac" then

                    ac =
                        value

                end

            end

        end

    end


    return battery,
        ac

end



------------------------------------------------------------
-- PMSET PRIVILÉGIÉ
------------------------------------------------------------

function obj:runPrivilegedPMSet(
    scope,
    value
)

    value =
        tonumber(value)


    if value ~= 0
        and value ~= 1 then


        self:log(
            "Valeur pmset invalide"
        )


        return false

    end


    if scope ~= "-b"
        and scope ~= "-c" then


        self:log(
            "Scope pmset invalide"
        )


        return false

    end


    local command =

        string.format(

            "%q -n %q %s lowpowermode %d",

            self.sudoPath,

            self.pmsetPath,

            scope,

            value

        )


    local output,
          success,
          terminationType,
          returnCode =

        hs.execute(

            command,

            true

        )


    if not success then

        self:log(

            "ERREUR pmset "
            ..
            scope
            ..
            " : "
            ..
            tostring(terminationType)
            ..
            " / "
            ..
            tostring(returnCode)
            ..
            " / "
            ..
            tostring(output)

        )

    end


    return success

end



------------------------------------------------------------
-- ACTIVER LOW POWER MODE
--
-- IMPORTANT :
--
-- Batterie et secteur sont traités séparément.
--
-- Un profil déjà à 1 :
--
--   - n'est pas modifié
--   - n'est pas remis à 0 à la sortie
------------------------------------------------------------

function obj:enableLowPowerMode()

    if not self:isLowPowerModeEnabled() then

        return false

    end


    --------------------------------------------------------
    -- Déjà géré pour cette session KEEPALIVE
    --------------------------------------------------------

    if self.lowPowerBatteryModified
        or self.lowPowerACModified then


        return true

    end


    local battery,
          ac =

        self:getLowPowerStates()


    if battery == nil
        and ac == nil then


        self:log(
            "Impossible de lire lowpowermode"
        )


        return false

    end


    self.savedLowPowerBattery =
        battery


    self.savedLowPowerAC =
        ac


    --------------------------------------------------------
    -- BATTERIE
    --------------------------------------------------------

    if battery ~= nil then

        if battery == 0 then

            if self:runPrivilegedPMSet(

                "-b",

                1

            ) then


                self.lowPowerBatteryModified =
                    true


                self:log(
                    "Low Power batterie activé temporairement"
                )

            end


        else

            self:log(
                "Low Power batterie déjà actif : inchangé"
            )

        end

    end


    --------------------------------------------------------
    -- SECTEUR
    --------------------------------------------------------

    if ac ~= nil then

        if ac == 0 then

            if self:runPrivilegedPMSet(

                "-c",

                1

            ) then


                self.lowPowerACModified =
                    true


                self:log(
                    "Low Power secteur activé temporairement"
                )

            end


        else

            self:log(
                "Low Power secteur déjà actif : inchangé"
            )

        end

    end


    return

        self.lowPowerBatteryModified

        or

        self.lowPowerACModified

        or

        battery == 1

        or

        ac == 1

end



------------------------------------------------------------
-- RESTAURER LOW POWER MODE
------------------------------------------------------------

function obj:restoreLowPowerMode()

    local allSuccess =
        true


    local hadModification =

        self.lowPowerBatteryModified

        or

        self.lowPowerACModified


    --------------------------------------------------------
    -- BATTERIE
    --
    -- Restaurer uniquement si ActivityKeeper l'a modifiée.
    --------------------------------------------------------

    if self.lowPowerBatteryModified then

        if not self:runPrivilegedPMSet(

            "-b",

            self.savedLowPowerBattery or 0

        ) then


            allSuccess =
                false

        else

            self:log(

                "Low Power batterie restauré : "
                ..
                tostring(
                    self.savedLowPowerBattery
                )

            )

        end

    end


    --------------------------------------------------------
    -- SECTEUR
    --------------------------------------------------------

    if self.lowPowerACModified then

        if not self:runPrivilegedPMSet(

            "-c",

            self.savedLowPowerAC or 0

        ) then


            allSuccess =
                false

        else

            self:log(

                "Low Power secteur restauré : "
                ..
                tostring(
                    self.savedLowPowerAC
                )

            )

        end

    end


    --------------------------------------------------------
    -- Reset uniquement en cas de restauration complète
    --------------------------------------------------------

    if allSuccess then

        self.savedLowPowerBattery =
            nil


        self.savedLowPowerAC =
            nil


        self.lowPowerBatteryModified =
            false


        self.lowPowerACModified =
            false

    end


    return

        hadModification
        and allSuccess

end



------------------------------------------------------------
-- APPLIQUER LES ÉCONOMIES
------------------------------------------------------------

function obj:applyEnergySavingState()

    --------------------------------------------------------
    -- Clavier
    --------------------------------------------------------

    self:disableKeyboardAutoBrightness()


    self:disableKeyboardBacklight()


    --------------------------------------------------------
    -- Écran
    --------------------------------------------------------

    self:dimScreen()


    --------------------------------------------------------
    -- Low Power
    --------------------------------------------------------

    self:enableLowPowerMode()

end



------------------------------------------------------------
-- RESTAURER LES ÉCONOMIES
------------------------------------------------------------

function obj:restoreEnergySavingState()

    --------------------------------------------------------
    -- Clavier
    --------------------------------------------------------

    local shouldConfirmKeyboardAuto =
        self.keyboardAutoBrightnessModified
        and self.savedKeyboardAutoBrightness == true


    self:restoreKeyboardAutoBrightness()


    self:restoreKeyboardBacklight(
        shouldConfirmKeyboardAuto
    )


    if shouldConfirmKeyboardAuto then

        self:scheduleKeyboardAutoBrightnessRestoreConfirm()

    end


    --------------------------------------------------------
    -- Écran
    --------------------------------------------------------

    self:restoreScreen()


    --------------------------------------------------------
    -- Low Power
    --------------------------------------------------------

    self:restoreLowPowerMode()

end



------------------------------------------------------------
-- KEEPALIVE
------------------------------------------------------------

function obj:sendKeepAlive()

    if self.currentState
        ~= self.STATE.KEEPALIVE then


        return

    end


    if self.keepAliveInProgress then

        return

    end


    self.keepAliveInProgress =
        true


    --------------------------------------------------------
    -- USER ACTIVITY
    --------------------------------------------------------

    local userSuccess =
        self:sendUserActivity()


    --------------------------------------------------------
    -- F20
    --------------------------------------------------------

    local keyboardSuccess =
        self:sendKeyboardActivity()


    --------------------------------------------------------
    -- SOURIS
    --------------------------------------------------------

    local mouseSuccess =
        self:sendMouseActivity()


    if keyboardSuccess then

        self:scheduleKeyboardBacklightEnforce()

    end


    --------------------------------------------------------
    -- Timestamp
    --------------------------------------------------------

    self.lastKeepAliveTime =
        os.time()


    --------------------------------------------------------
    -- Statistiques
    --------------------------------------------------------

    if userSuccess
        or keyboardSuccess
        or mouseSuccess then


        self.keepAliveCount =
            self.keepAliveCount
            +
            1


        self:log(

            string.format(

                "Keepalive #%d | UA=%s F20=%s Mouse=%s",

                self.keepAliveCount,

                tostring(
                    self:isUserActivityEnabled()
                ),

                tostring(
                    self:isKeyboardEnabled()
                ),

                tostring(
                    self:isMouseEnabled()
                )

            )

        )


    else

        self:log(
            "ATTENTION : aucun moteur keepalive actif"
        )

    end


    self.keepAliveInProgress =
        false

end


function obj:scheduleInitialKeepAlive()

    if self.initialKeepAliveTimer then

        self.initialKeepAliveTimer:stop()


        self.initialKeepAliveTimer =
            nil

    end


    self.initialKeepAliveTimer =

        hs.timer.doAfter(

            self.keepAliveAfterEnergySavingDelay,

            function()

                self.initialKeepAliveTimer =
                    nil


                if self.currentState
                    ~= self.STATE.KEEPALIVE then


                    return

                end


                self:forceKeyboardBacklightOffAfterKeepAlive()


                self:sendKeepAlive()

            end

        )


    return self

end



------------------------------------------------------------
-- CONTRÔLE IDLE
------------------------------------------------------------

function obj:checkIdleState()

    if self.currentState == self.STATE.OFF then

        return

    end


    local idle =
        self:getIdleTime()


    --------------------------------------------------------
    -- En mode jaune :
    -- mémoriser les valeurs clavier non nulles disponibles.
    --------------------------------------------------------

    if self.currentState == self.STATE.MONITORING then

        self:sampleKeyboardBrightness(false)

    end


    if self.verboseLogging then

        self:log(

            string.format(

                "state=%s idle=%.1f",

                self.currentState,

                idle

            )

        )

    end


    --------------------------------------------------------
    -- JAUNE -> VERT
    --------------------------------------------------------

    if self.currentState == self.STATE.MONITORING then

        if idle >= self.idleThreshold then

            ------------------------------------------------
            -- Passage vert
            ------------------------------------------------

            self:setState(
                self.STATE.KEEPALIVE
            )


            ------------------------------------------------
            -- Économies énergie
            ------------------------------------------------

            self:applyEnergySavingState()


            ------------------------------------------------
            -- Premier keepalive après stabilisation clavier.
            ------------------------------------------------

            self:scheduleInitialKeepAlive()

        end


        return

    end


    --------------------------------------------------------
    -- MODE KEEPALIVE
    --------------------------------------------------------

    if self.currentState == self.STATE.KEEPALIVE then

        local secondsSinceKeepAlive =
            nil


        if self.lastKeepAliveTime then

            secondsSinceKeepAlive =
                os.time()
                -
                self.lastKeepAliveTime

        end


        if idle <= self.realActivityReturnIdleThreshold
            and (
                not secondsSinceKeepAlive
                or secondsSinceKeepAlive
                    > self.postKeepAliveIdleIgnorePeriod
            ) then


            self:log(
                "Activité utilisateur détectée par idle macOS"
            )


            self:restoreEnergySavingState()


            self:setState(
                self.STATE.MONITORING
            )


            return

        end


        if not self.lastKeepAliveTime then

            self:sendKeepAlive()


            return

        end


        local elapsed =

            os.time()
            -
            self.lastKeepAliveTime


        if elapsed
            >= self.keepAliveInterval then


            self:sendKeepAlive()

        end

    end

end



------------------------------------------------------------
-- ACTIVATION
------------------------------------------------------------

function obj:enable()

    if self.currentState ~= self.STATE.OFF then

        return self

    end


    self.lastRealActivityTime =
        os.time()


    self.lastKeepAliveTime =
        nil


    --------------------------------------------------------
    -- Tentative de référence clavier immédiate
    --------------------------------------------------------

    self:sampleKeyboardBrightness(true)


    --------------------------------------------------------
    -- Passage jaune
    --------------------------------------------------------

    self:setState(
        self.STATE.MONITORING
    )


    --------------------------------------------------------
    -- Watcher
    --------------------------------------------------------

    self:createInputWatcher()


    if self.inputWatcher then

        self.inputWatcher:start()

    end


    --------------------------------------------------------
    -- Timer précédent éventuel
    --------------------------------------------------------

    if self.checkTimer then

        self.checkTimer:stop()


        self.checkTimer =
            nil

    end


    --------------------------------------------------------
    -- Timer principal
    --------------------------------------------------------

    self.checkTimer =

        hs.timer.doEvery(

            self.checkInterval,

            function()

                self:checkIdleState()

            end

        )


    --------------------------------------------------------
    -- Contrôle immédiat
    --------------------------------------------------------

    self:checkIdleState()


    self:log(

        string.format(

            "Activé | UA=%s F20=%s Mouse=%s KBLight=%s Screen=%s LowPower=%s",

            tostring(
                self:isUserActivityEnabled()
            ),

            tostring(
                self:isKeyboardEnabled()
            ),

            tostring(
                self:isMouseEnabled()
            ),

            tostring(
                self:isKeyboardBacklightEnabled()
            ),

            tostring(
                self:isScreenDimmingEnabled()
            ),

            tostring(
                self:isLowPowerModeEnabled()
            )

        )

    )


    return self

end



------------------------------------------------------------
-- DÉSACTIVATION
------------------------------------------------------------

function obj:disable()

    if self.currentState == self.STATE.OFF then

        return self

    end


    --------------------------------------------------------
    -- Restaurer avant arrêt
    --------------------------------------------------------

    self:restoreEnergySavingState()


    --------------------------------------------------------
    -- Timer principal
    --------------------------------------------------------

    if self.checkTimer then

        self.checkTimer:stop()


        self.checkTimer =
            nil

    end


    --------------------------------------------------------
    -- Souris
    --------------------------------------------------------

    if self.returnMouseTimer then

        self.returnMouseTimer:stop()


        self.returnMouseTimer =
            nil

    end


    --------------------------------------------------------
    -- Key Up
    --------------------------------------------------------

    if self.keyUpTimer then

        self.keyUpTimer:stop()


        self.keyUpTimer =
            nil

    end


    --------------------------------------------------------
    -- Probe clavier
    --------------------------------------------------------

    if self.keyboardBacklightProbeTimer then

        self.keyboardBacklightProbeTimer:stop()


        self.keyboardBacklightProbeTimer =
            nil

    end


    if self.keyboardBacklightProbeRetryTimer then

        self.keyboardBacklightProbeRetryTimer:stop()


        self.keyboardBacklightProbeRetryTimer =
            nil

    end


    if self.keyboardBacklightEnforceTimer then

        self.keyboardBacklightEnforceTimer:stop()


        self.keyboardBacklightEnforceTimer =
            nil

    end


    if self.initialKeepAliveTimer then

        self.initialKeepAliveTimer:stop()


        self.initialKeepAliveTimer =
            nil

    end


    if self.keyboardAutoRestoreTimer then

        self.keyboardAutoRestoreTimer:stop()


        self.keyboardAutoRestoreTimer =
            nil

    end


    --------------------------------------------------------
    -- Watcher
    --------------------------------------------------------

    if self.inputWatcher then

        self.inputWatcher:stop()

    end


    self:stopFastReturnWatcher()


    --------------------------------------------------------
    -- Reset
    --------------------------------------------------------

    self.keepAliveInProgress =
        false


    self.syntheticEventIgnoreUntil =
        0


    self.lastKeepAliveTime =
        nil


    --------------------------------------------------------
    -- OFF
    --------------------------------------------------------

    self:setState(
        self.STATE.OFF
    )


    self:log(
        "ActivityKeeper désactivé"
    )


    return self

end



------------------------------------------------------------
-- TOGGLE GLOBAL
------------------------------------------------------------

function obj:toggle()

    if self.currentState == self.STATE.OFF then

        return self:enable()

    end


    return self:disable()

end



------------------------------------------------------------
-- TOGGLE USER ACTIVITY
------------------------------------------------------------

function obj:toggleUserActivityMode()

    self:setBooleanSetting(

        self.SETTING_KEYS.USER_ACTIVITY,

        not self:isUserActivityEnabled(),

        "UserActivity"

    )


    return self

end



------------------------------------------------------------
-- TOGGLE F20
------------------------------------------------------------

function obj:toggleKeyboardMode()

    self:setBooleanSetting(

        self.SETTING_KEYS.KEYBOARD,

        not self:isKeyboardEnabled(),

        "Clavier F20"

    )


    return self

end



------------------------------------------------------------
-- TOGGLE SOURIS
------------------------------------------------------------

function obj:toggleMouseMode()

    self:setBooleanSetting(

        self.SETTING_KEYS.MOUSE,

        not self:isMouseEnabled(),

        "Souris"

    )


    return self

end



------------------------------------------------------------
-- TOGGLE BACKLIGHT CLAVIER
------------------------------------------------------------

function obj:toggleKeyboardBacklightMode()

    local enabled =
        not self:isKeyboardBacklightEnabled()


    self:setBooleanSetting(

        self.SETTING_KEYS.KEYBOARD_BACKLIGHT,

        enabled,

        "Rétroéclairage clavier"

    )


    --------------------------------------------------------
    -- Application immédiate en KEEPALIVE
    --------------------------------------------------------

    if self.currentState == self.STATE.KEEPALIVE then

        if enabled then

            self:disableKeyboardBacklight()

        else

            self:restoreKeyboardBacklight()

        end

    end


    return self

end



------------------------------------------------------------
-- TOGGLE SCREEN DIMMING
------------------------------------------------------------

function obj:toggleScreenDimmingMode()

    local enabled =
        not self:isScreenDimmingEnabled()


    self:setBooleanSetting(

        self.SETTING_KEYS.SCREEN_DIMMING,

        enabled,

        "Réduction luminosité écran"

    )


    --------------------------------------------------------
    -- Application immédiate en KEEPALIVE
    --------------------------------------------------------

    if self.currentState == self.STATE.KEEPALIVE then

        if enabled then

            self:dimScreen()

        else

            self:restoreScreen()

        end

    end


    return self

end



------------------------------------------------------------
-- TOGGLE LOW POWER
------------------------------------------------------------

function obj:toggleLowPowerMode()

    local enabled =
        not self:isLowPowerModeEnabled()


    self:setBooleanSetting(

        self.SETTING_KEYS.LOW_POWER,

        enabled,

        "Mode économie d'énergie"

    )


    --------------------------------------------------------
    -- Application immédiate en KEEPALIVE
    --------------------------------------------------------

    if self.currentState == self.STATE.KEEPALIVE then

        if enabled then

            self:enableLowPowerMode()

        else

            self:restoreLowPowerMode()

        end

    end


    return self

end



------------------------------------------------------------
-- TEST KEEPALIVE
--
-- Test uniquement :
--
--   UserActivity
--   F20
--   Souris
--
-- Ne modifie pas les économies d'énergie.
------------------------------------------------------------

function obj:testKeepAlive()

    self:log(
        "Test manuel keepalive"
    )


    local previousState =
        self.currentState


    self.currentState =
        self.STATE.KEEPALIVE


    self:sendKeepAlive()


    self.currentState =
        previousState


    self:updateMenuBar()


    hs.alert.show(
        "Test keepalive envoyé"
    )


    return self

end



------------------------------------------------------------
-- CHECKBOX MENU
------------------------------------------------------------

function obj:menuCheck(value)

    if value then

        return "✓ "

    end


    return "    "

end



------------------------------------------------------------
-- CONSTRUCTION MENU
------------------------------------------------------------

function obj:buildMenu()

    local menu =
        {}


    --------------------------------------------------------
    -- INFORMATIONS
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "État : "
                ..
                self:getStateLabel(),

            disabled =
                true
        }

    )


    table.insert(

        menu,

        {
            title =
                "Idle macOS : "
                ..
                self:formatDuration(
                    self:getIdleTime()
                ),

            disabled =
                true
        }

    )


    table.insert(

        menu,

        {
            title =
                "Seuil : "
                ..
                self:formatDuration(
                    self.idleThreshold
                ),

            disabled =
                true
        }

    )


    table.insert(

        menu,

        {
            title =
                "Intervalle : "
                ..
                self:formatDuration(
                    self.keepAliveInterval
                ),

            disabled =
                true
        }

    )


    if self.lastKeepAliveTime then

        table.insert(

            menu,

            {
                title =
                    "Dernier keepalive : "
                    ..
                    os.date(

                        "%H:%M:%S",

                        self.lastKeepAliveTime

                    ),

                disabled =
                    true
            }

        )

    end


    table.insert(

        menu,

        {
            title =
                "Keepalive générés : "
                ..
                tostring(
                    self.keepAliveCount
                ),

            disabled =
                true
        }

    )


    --------------------------------------------------------
    -- Valeur clavier mémorisée
    --------------------------------------------------------

    if self.lastKnownNonZeroKeyboardBrightness then

        table.insert(

            menu,

            {
                title =
                    string.format(

                        "Référence clavier : %.2f",

                        self.lastKnownNonZeroKeyboardBrightness

                    ),

                disabled =
                    true
            }

        )

    end


    table.insert(
        menu,
        {
            title = "-"
        }
    )


    --------------------------------------------------------
    -- MODES DE MAINTIEN
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Maintien de présence",

            disabled =
                true
        }

    )


    --------------------------------------------------------
    -- USER ACTIVITY
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isUserActivityEnabled()
                )
                ..
                "UserActivity",

            fn =
                function()

                    self:toggleUserActivityMode()

                end
        }

    )


    --------------------------------------------------------
    -- F20
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isKeyboardEnabled()
                )
                ..
                "Clavier F20",

            fn =
                function()

                    self:toggleKeyboardMode()

                end
        }

    )


    --------------------------------------------------------
    -- SOURIS
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isMouseEnabled()
                )
                ..
                "Souris",

            fn =
                function()

                    self:toggleMouseMode()

                end
        }

    )


    table.insert(
        menu,
        {
            title = "-"
        }
    )


    --------------------------------------------------------
    -- RÉDUCTION CONSOMMATION
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Réduction consommation",

            disabled =
                true
        }

    )


    --------------------------------------------------------
    -- CLAVIER
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isKeyboardBacklightEnabled()
                )
                ..
                "Éteindre rétroéclairage clavier",

            fn =
                function()

                    self:toggleKeyboardBacklightMode()

                end
        }

    )


    --------------------------------------------------------
    -- ÉCRAN
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isScreenDimmingEnabled()
                )
                ..
                string.format(

                    "Réduire écran à %d %%",

                    math.floor(

                        self.screenBrightnessTarget
                        *
                        100

                    )

                ),

            fn =
                function()

                    self:toggleScreenDimmingMode()

                end
        }

    )


    --------------------------------------------------------
    -- LOW POWER
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                self:menuCheck(
                    self:isLowPowerModeEnabled()
                )
                ..
                "Mode économie d'énergie",

            fn =
                function()

                    self:toggleLowPowerMode()

                end
        }

    )


    --------------------------------------------------------
    -- BACKEND
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Clavier : "
                ..
                self:getKeyboardBacklightBackendLabel(),

            disabled =
                true
        }

    )


    table.insert(
        menu,
        {
            title = "-"
        }
    )


    --------------------------------------------------------
    -- GLOBAL
    --------------------------------------------------------

    if self.currentState == self.STATE.OFF then

        table.insert(

            menu,

            {
                title =
                    "Activer Activity Keeper",

                fn =
                    function()

                        self:enable()

                    end
            }

        )


    else

        table.insert(

            menu,

            {
                title =
                    "Désactiver Activity Keeper",

                fn =
                    function()

                        self:disable()

                    end
            }

        )

    end


    --------------------------------------------------------
    -- TEST
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Tester les modes actifs",

            fn =
                function()

                    self:testKeepAlive()

                end
        }

    )


    table.insert(
        menu,
        {
            title = "-"
        }
    )


    table.insert(

        menu,

        {
            title =
                "Double-clic : ON / OFF",

            disabled =
                true
        }

    )


    table.insert(
        menu,
        {
            title = "-"
        }
    )


    --------------------------------------------------------
    -- CONSOLE
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Ouvrir la console",

            fn =
                function()

                    hs.openConsole()

                end
        }

    )


    --------------------------------------------------------
    -- RELOAD
    --------------------------------------------------------

    table.insert(

        menu,

        {
            title =
                "Recharger Hammerspoon",

            fn =
                function()

                    hs.reload()

                end
        }

    )


    return menu

end



------------------------------------------------------------
-- AFFICHER MENU
------------------------------------------------------------

function obj:showMenu()

    if not self.menuBar then

        return

    end


    self.menuBar:setMenu(
        self:buildMenu()
    )


    local frame =
        self.menuBar:frame()


    if not frame then

        self.menuBar:setMenu(nil)


        return

    end


    self.menuBar:popupMenu({

        x =
            frame.x,

        y =
            frame.y
            +
            frame.h

    })


    --------------------------------------------------------
    -- Détachement pour conserver le clickCallback
    --------------------------------------------------------

    hs.timer.doAfter(

        0.1,

        function()

            if self.menuBar then

                self.menuBar:setMenu(nil)

            end

        end

    )

end



------------------------------------------------------------
-- SIMPLE / DOUBLE CLIC
------------------------------------------------------------

function obj:handleMenuBarClick()

    self.clickCount =
        self.clickCount
        +
        1


    --------------------------------------------------------
    -- PREMIER CLIC
    --------------------------------------------------------

    if self.clickCount == 1 then

        self.clickTimer =

            hs.timer.doAfter(

                self.doubleClickInterval,

                function()

                    if self.clickCount == 1 then

                        self:showMenu()

                    end


                    self.clickCount =
                        0


                    self.clickTimer =
                        nil

                end

            )


        return

    end


    --------------------------------------------------------
    -- DOUBLE CLIC
    --------------------------------------------------------

    if self.clickCount >= 2 then

        if self.clickTimer then

            self.clickTimer:stop()


            self.clickTimer =
                nil

        end


        self.clickCount =
            0


        self:toggle()

    end

end



------------------------------------------------------------
-- CRÉATION MENUBAR
------------------------------------------------------------

function obj:createMenuBar()

    if self.menuBar then

        self:updateMenuBar()


        return self

    end


    self.menuBar =
        hs.menubar.new()


    if not self.menuBar then

        self:log(
            "ERREUR création menubar"
        )


        return self

    end


    self:updateMenuBar()


    self.menuBar:setClickCallback(

        function()

            self:handleMenuBarClick()

        end

    )


    return self

end



------------------------------------------------------------
-- HOTKEYS
------------------------------------------------------------

function obj:bindHotkeys(mapping)

    --------------------------------------------------------
    -- Nettoyage existant
    --------------------------------------------------------

    for _, hotkey
        in pairs(self.hotkeys) do


        if hotkey then

            hotkey:delete()

        end

    end


    self.hotkeys =
        {}


    --------------------------------------------------------
    -- TOGGLE
    --------------------------------------------------------

    if mapping
        and mapping.toggle
        and mapping.toggle[1]
        and mapping.toggle[2] then


        self.hotkeys.toggle =

            hs.hotkey.bind(

                mapping.toggle[1],

                mapping.toggle[2],

                function()

                    self:toggle()

                end

            )

    end


    return self

end



------------------------------------------------------------
-- START
------------------------------------------------------------

function obj:start(enableImmediately)

    self:applyConfiguredModeDefaults()


    --------------------------------------------------------
    -- Détection outil clavier
    --------------------------------------------------------

    self:detectKeyboardBrightnessTool()


    --------------------------------------------------------
    -- Watcher
    --------------------------------------------------------

    self:createInputWatcher()


    --------------------------------------------------------
    -- Menubar
    --------------------------------------------------------

    self:createMenuBar()


    --------------------------------------------------------
    -- État initial
    --------------------------------------------------------

    self.currentState =
        self.STATE.OFF


    self:updateMenuBar()


    --------------------------------------------------------
    -- Activation automatique facultative
    --------------------------------------------------------

    if enableImmediately == true then

        self:enable()

    end


    self:log(

        string.format(

            "Initialisé | F20=%s Screen=%s LowPower=%s Backend=%s",

            tostring(
                self:isKeyboardEnabled()
            ),

            tostring(
                self:isScreenDimmingEnabled()
            ),

            tostring(
                self:isLowPowerModeEnabled()
            ),

            self:getKeyboardBacklightBackendLabel()

        )

    )


    return self

end



------------------------------------------------------------
-- STOP COMPLET
------------------------------------------------------------

function obj:stop()

    --------------------------------------------------------
    -- Désactivation et restauration
    --------------------------------------------------------

    self:disable()


    --------------------------------------------------------
    -- Sécurité supplémentaire
    --------------------------------------------------------

    self:restoreEnergySavingState()


    --------------------------------------------------------
    -- Timers
    --------------------------------------------------------

    if self.clickTimer then

        self.clickTimer:stop()


        self.clickTimer =
            nil

    end


    if self.returnMouseTimer then

        self.returnMouseTimer:stop()


        self.returnMouseTimer =
            nil

    end


    if self.keyUpTimer then

        self.keyUpTimer:stop()


        self.keyUpTimer =
            nil

    end


    if self.keyboardBacklightProbeTimer then

        self.keyboardBacklightProbeTimer:stop()


        self.keyboardBacklightProbeTimer =
            nil

    end


    if self.keyboardBacklightProbeRetryTimer then

        self.keyboardBacklightProbeRetryTimer:stop()


        self.keyboardBacklightProbeRetryTimer =
            nil

    end


    --------------------------------------------------------
    -- Hotkeys
    --------------------------------------------------------

    for _, hotkey
        in pairs(self.hotkeys) do


        if hotkey then

            hotkey:delete()

        end

    end


    self.hotkeys =
        {}


    --------------------------------------------------------
    -- Menubar
    --------------------------------------------------------

    if self.menuBar then

        self.menuBar:delete()


        self.menuBar =
            nil

    end


    --------------------------------------------------------
    -- Watcher
    --------------------------------------------------------

    if self.inputWatcher then

        self.inputWatcher:stop()


        self.inputWatcher =
            nil

    end


    self:log(
        "Spoon arrêté"
    )


    return self

end



------------------------------------------------------------
-- RETOUR SPOON
------------------------------------------------------------

return obj
