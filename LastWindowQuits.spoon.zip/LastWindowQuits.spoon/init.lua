------------------------------------------------------------
-- LastWindowQuits Spoon
--
-- Version : 1.0.0
--
-- Ferme automatiquement une application quand sa derniere
-- fenetre est fermee, avec delai, blacklist, pause temporaire
-- et journalisation.
--
-- Interactions :
--
--   Simple clic :
--       ouvre le menu
--
--   Double clic :
--       active / desactive temporairement
--
--   Raccourcis :
--       configurables via bindHotkeys()
--
------------------------------------------------------------


local obj = {}

obj.__index = obj



------------------------------------------------------------
-- METADONNEES
------------------------------------------------------------

obj.name = "LastWindowQuits"

obj.version = "1.0.0"

obj.author = "Benjamin Cerede / OpenAI"

obj.homepage = "Local Spoon"

obj.license = "MIT"



------------------------------------------------------------
-- CONFIGURATION PUBLIQUE
------------------------------------------------------------

obj.enabled = true

obj.quitDelay = 2

obj.scanAfterLaunchDelay = 3

obj.startupGracePeriod = 5

obj.doubleClickInterval = 0.25

obj.showMenuBar = false

obj.showNotifications = true

obj.verboseLogging = false

obj.logToFile = true

obj.logFile = os.getenv("HOME") .. "/.hammerspoon/LastWindowQuits.log"

obj.maxLogAgeSeconds = 24 * 60 * 60

obj.logCleanupInterval = 60 * 60

obj.useIgnoredBundlesFile = true

obj.ignoredBundlesFile = nil

obj.persistMenuChanges = true

obj.trackOnlyAppsAfterWindowClose = true


obj.blacklistBundleIDs = {}


obj.blacklistAppNames = {
}


obj.backgroundBundleIDs = {
    ["com.apple.controlcenter"] = true,
    ["com.apple.securityagent"] = true,
    ["com.apple.systemevents"] = true,
    ["com.hammerspoon.Hammerspoon"] = true,
}


obj.backgroundAppNames = {
    ["Hammerspoon"] = true,
}



------------------------------------------------------------
-- VARIABLES INTERNES
------------------------------------------------------------

obj.windowFilter =
    nil


obj.windowCreatedCallback =
    nil


obj.windowDestroyedCallback =
    nil


obj.appWatcher =
    nil


obj.menuBar =
    nil


obj.hotkeys =
    {}


obj.pendingQuits =
    {}


obj.ignoredBundlesFileEntries =
    {}


obj.seenApps =
    {}


obj.pausedUntil =
    nil


obj.startedAt =
    nil


obj.clickCount =
    0


obj.clickTimer =
    nil


obj.lastLogCleanupAt =
    0


obj.logCleanupInProgress =
    false


obj.settingsKey =
    "LastWindowQuits.settings"



------------------------------------------------------------
-- OUTILS TABLES
------------------------------------------------------------

function obj:copyTable(source)

    local copy =
        {}


    if not source then

        return copy

    end


    for key, value in pairs(source) do

        copy[key] =
            value

    end


    return copy

end


function obj:sortedKeys(source)

    local keys =
        {}


    for key, value in pairs(source or {}) do

        if value then

            table.insert(
                keys,
                key
            )

        end

    end


    table.sort(keys)


    return keys

end


function obj:trim(value)

    if not value then

        return ""

    end


    return (
        tostring(value)
            :gsub("^%s+", "")
            :gsub("%s+$", "")
    )

end


function obj:defaultIgnoredBundlesFile()

    local source =
        debug.getinfo(1, "S").source or ""


    local spoonDirectory =
        source:match("^@(.+)/[^/]+$")


    if spoonDirectory then

        return spoonDirectory .. "/ignored-bundles.txt"

    end


    return os.getenv("HOME")
        .. "/.hammerspoon/Spoons/LastWindowQuits.spoon/ignored-bundles.txt"

end


function obj:ensureIgnoredBundlesFilePath()

    if not self.ignoredBundlesFile then

        self.ignoredBundlesFile =
            self:defaultIgnoredBundlesFile()

    end


    return self

end


function obj:readIgnoredBundlesFile()

    self:ensureIgnoredBundlesFilePath()


    local entries =
        {}


    local file =
        io.open(
            self.ignoredBundlesFile,
            "r"
        )


    if not file then

        return entries

    end


    for line in file:lines() do

        local value =
            self:trim(
                line:gsub("#.*$", "")
            )


        if value ~= "" then

            entries[value] =
                true

        end

    end


    file:close()


    return entries

end


function obj:writeIgnoredBundlesFile(entries)

    self:ensureIgnoredBundlesFilePath()


    local file =
        io.open(
            self.ignoredBundlesFile,
            "w"
        )


    if not file then

        self:log(
            "Impossible d'ecrire "
            .. tostring(self.ignoredBundlesFile),
            true
        )


        return false

    end


    for _, bundleID in ipairs(self:sortedKeys(entries)) do

        file:write(
            bundleID .. "\n"
        )

    end


    file:close()


    return true

end


function obj:reloadIgnoredBundlesFile()

    if not self.useIgnoredBundlesFile then

        return self

    end


    self:ensureIgnoredBundlesFilePath()


    for bundleID in pairs(self.ignoredBundlesFileEntries or {}) do

        self.blacklistBundleIDs[bundleID] =
            nil

    end


    self.ignoredBundlesFileEntries =
        self:readIgnoredBundlesFile()


    for bundleID in pairs(self.ignoredBundlesFileEntries) do

        self.blacklistBundleIDs[bundleID] =
            true

    end


    self:updateMenuBar()


    self:log(
        "Fichier bundles ignore recharge : "
        .. tostring(self.ignoredBundlesFile),
        true
    )


    return self

end


function obj:addBundleIDToIgnoredFile(bundleID)

    if not bundleID then

        return false

    end


    local entries =
        self:readIgnoredBundlesFile()


    entries[bundleID] =
        true


    if self:writeIgnoredBundlesFile(entries) then

        self:reloadIgnoredBundlesFile()

        return true

    end


    return false

end


function obj:removeBundleIDFromIgnoredFile(bundleID)

    if not bundleID then

        return false

    end


    local entries =
        self:readIgnoredBundlesFile()


    entries[bundleID] =
        nil


    if self:writeIgnoredBundlesFile(entries) then

        self:reloadIgnoredBundlesFile()

        return true

    end


    return false

end


function obj:mergePersistentSettings()

    local settings =
        hs.settings.get(self.settingsKey)


    if type(settings) ~= "table" then

        return self

    end


    if type(settings.enabled) == "boolean" then

        self.enabled =
            settings.enabled

    end


    if type(settings.quitDelay) == "number" then

        self.quitDelay =
            settings.quitDelay

    end


    if type(settings.verboseLogging) == "boolean" then

        self.verboseLogging =
            settings.verboseLogging

    end


    if type(settings.logToFile) == "boolean" then

        self.logToFile =
            settings.logToFile

    end


    if not self.useIgnoredBundlesFile
        and type(settings.blacklistBundleIDs) == "table" then

        self.blacklistBundleIDs =
            settings.blacklistBundleIDs

    end


    if type(settings.blacklistAppNames) == "table" then

        self.blacklistAppNames =
            settings.blacklistAppNames

    end


    return self

end


function obj:savePersistentSettings()

    if not self.persistMenuChanges then

        return self

    end


    local settings = {
        enabled = self.enabled,
        quitDelay = self.quitDelay,
        verboseLogging = self.verboseLogging,
        logToFile = self.logToFile,
        blacklistAppNames = self.blacklistAppNames,
    }


    if not self.useIgnoredBundlesFile then

        settings.blacklistBundleIDs =
            self.blacklistBundleIDs

    end


    hs.settings.set(
        self.settingsKey,
        settings
    )


    return self

end



------------------------------------------------------------
-- LOG
------------------------------------------------------------

function obj:timestampFromLogLine(line)

    local year,
          month,
          day,
          hour,
          minute,
          second =
        tostring(line or ""):match(
            "^(%d%d%d%d)%-(%d%d)%-(%d%d) (%d%d):(%d%d):(%d%d)"
        )


    if not year then

        return nil

    end


    return os.time({
        year = tonumber(year),
        month = tonumber(month),
        day = tonumber(day),
        hour = tonumber(hour),
        min = tonumber(minute),
        sec = tonumber(second),
    })

end


function obj:cleanLogFile(force)

    if not self.logToFile
        or not self.maxLogAgeSeconds
        or self.maxLogAgeSeconds <= 0
        or self.logCleanupInProgress then

        return self

    end


    local now =
        self:now()


    if force ~= true
        and self.lastLogCleanupAt
        and now - self.lastLogCleanupAt < self.logCleanupInterval then

        return self

    end


    self.lastLogCleanupAt =
        now


    local file =
        io.open(
            self.logFile,
            "r"
        )


    if not file then

        return self

    end


    self.logCleanupInProgress =
        true


    local keepAfter =
        now - self.maxLogAgeSeconds


    local lines =
        {}


    for line in file:lines() do

        local timestamp =
            self:timestampFromLogLine(line)


        if not timestamp
            or timestamp >= keepAfter then

            table.insert(
                lines,
                line
            )

        end

    end


    file:close()


    file =
        io.open(
            self.logFile,
            "w"
        )


    if file then

        for _, line in ipairs(lines) do

            file:write(
                line .. "\n"
            )

        end


        file:close()

    end


    self.logCleanupInProgress =
        false


    return self

end


function obj:log(message, always)

    if always ~= true
        and not self.verboseLogging then

        return

    end


    local line =
        string.format(
            "%s - LastWindowQuits %s - %s",
            os.date("%Y-%m-%d %H:%M:%S"),
            self.version,
            tostring(message)
        )


    print(line)


    if not self.logToFile then

        return

    end


    self:cleanLogFile(false)


    local file =
        io.open(
            self.logFile,
            "a"
        )


    if file then

        file:write(
            line .. "\n"
        )

        file:close()

    end

end


function obj:notify(title, message)

    if not self.showNotifications then

        return

    end


    hs.notify.new({
        title = title,
        informativeText = message,
    }):send()

end



------------------------------------------------------------
-- FORMATAGE
------------------------------------------------------------

function obj:now()

    return hs.timer.secondsSinceEpoch()

end


function obj:formatDuration(seconds)

    seconds =
        math.max(
            0,
            math.floor(seconds or 0)
        )


    if seconds < 60 then

        return tostring(seconds) .. " sec"

    end


    local minutes =
        math.floor(seconds / 60)


    if minutes < 60 then

        return tostring(minutes) .. " min"

    end


    local hours =
        math.floor(minutes / 60)


    local remainingMinutes =
        minutes % 60


    return string.format(
        "%d h %02d min",
        hours,
        remainingMinutes
    )

end


function obj:appDisplayName(appInfo)

    if not appInfo then

        return "Application inconnue"

    end


    return appInfo.name
        or appInfo.bundleID
        or "Application inconnue"

end



------------------------------------------------------------
-- INFORMATIONS APPLICATION
------------------------------------------------------------

function obj:appInfoFromWindow(window, appName)

    local application =
        nil


    if window then

        local ok,
              result =
            pcall(
                function()

                    return window:application()

                end
            )


        if ok then

            application =
                result

        end

    end


    local bundleID =
        nil


    local name =
        appName


    if application then

        bundleID =
            application:bundleID()

        name =
            application:name() or name

    end


    return {
        app = application,
        bundleID = bundleID,
        name = name,
    }

end


function obj:appInfoFromApplication(application)

    if not application then

        return nil

    end


    return {
        app = application,
        bundleID = application:bundleID(),
        name = application:name(),
    }

end


function obj:appInfoFromBundleID(bundleID, name)

    local application =
        nil


    if bundleID then

        application =
            hs.application.get(bundleID)

    end


    if not application
        and name then

        application =
            hs.application.get(name)

    end


    if not application then

        return {
            app = nil,
            bundleID = bundleID,
            name = name,
        }

    end


    return self:appInfoFromApplication(
        application
    )

end


function obj:appKey(appInfo)

    if not appInfo then

        return nil

    end


    return appInfo.bundleID
        or appInfo.name

end


function obj:markSeen(appInfo)

    local key =
        self:appKey(appInfo)


    if key then

        self.seenApps[key] =
            true

    end

end


function obj:hasSeen(appInfo)

    if not self.trackOnlyAppsAfterWindowClose then

        return true

    end


    local key =
        self:appKey(appInfo)


    return key
        and self.seenApps[key] == true

end



------------------------------------------------------------
-- FILTRAGE APPLICATIONS / FENETRES
------------------------------------------------------------

function obj:isPaused()

    return self.pausedUntil
        and self.pausedUntil > self:now()

end


function obj:isInStartupGrace()

    return self.startedAt
        and self.startupGracePeriod
        and self.startupGracePeriod > 0
        and self:now() - self.startedAt < self.startupGracePeriod

end


function obj:pauseFor(seconds)

    self.pausedUntil =
        self:now() + seconds


    self:updateMenuBar()


    self:log(
        "Pause temporaire : "
        .. self:formatDuration(seconds),
        true
    )


    self:notify(
        "Last Window Quits en pause",
        "Reprise dans " .. self:formatDuration(seconds)
    )


    return self

end


function obj:resume()

    self.pausedUntil =
        nil


    self:updateMenuBar()


    self:log(
        "Reprise",
        true
    )


    return self

end


function obj:isAppBlacklisted(appInfo)

    if not appInfo then

        return true

    end


    if appInfo.bundleID
        and self.blacklistBundleIDs[appInfo.bundleID] then

        return true

    end


    if appInfo.name
        and self.blacklistAppNames[appInfo.name] then

        return true

    end


    return false

end


function obj:isBackgroundApp(appInfo)

    if not appInfo then

        return true

    end


    if appInfo.bundleID
        and self.backgroundBundleIDs[appInfo.bundleID] then

        return true

    end


    if appInfo.name
        and self.backgroundAppNames[appInfo.name] then

        return true

    end


    return false

end


function obj:isApplicationAllowed(appInfo)

    if not appInfo then

        return false,
            "application inconnue"

    end


    if self:isAppBlacklisted(appInfo) then

        return false,
            "blacklist"

    end


    if self:isBackgroundApp(appInfo) then

        return false,
            "app de fond exclue"

    end


    return true,
        "eligible"

end


function obj:isCountableWindow(window)

    if not window then

        return false

    end


    local ok,
          standard =
        pcall(
            function()

                return window:isStandard()

            end
        )


    if ok
        and standard == false then

        return false

    end


    return true

end


function obj:countWindows(application)

    if not application then

        return 0

    end


    local windows =
        application:allWindows()


    local count =
        0


    for _, window in ipairs(windows or {}) do

        if self:isCountableWindow(window) then

            count =
                count + 1

        end

    end


    return count

end



------------------------------------------------------------
-- QUIT DIFFERE
------------------------------------------------------------

function obj:cancelPendingQuit(appInfo, reason)

    local key =
        self:appKey(appInfo)


    if not key then

        return self

    end


    local pending =
        self.pendingQuits[key]


    if not pending then

        return self

    end


    if pending.timer then

        pending.timer:stop()

    end


    self.pendingQuits[key] =
        nil


    self:log(
        string.format(
            "Quit annule pour %s (%s)",
            self:appDisplayName(appInfo),
            reason or "raison inconnue"
        ),
        true
    )


    self:updateMenuBar()


    return self

end


function obj:scheduleQuit(appInfo, reason)

    local key =
        self:appKey(appInfo)


    if not key then

        return self

    end


    self:markSeen(appInfo)


    if not self.enabled then

        self:log(
            "Pas de quit pour "
            .. self:appDisplayName(appInfo)
            .. " : Spoon desactive",
            true
        )

        return self

    end


    if self:isPaused() then

        self:log(
            "Pas de quit pour "
            .. self:appDisplayName(appInfo)
            .. " : pause temporaire",
            true
        )

        return self

    end


    local allowed,
          allowedReason =
        self:isApplicationAllowed(appInfo)


    if not allowed then

        self:log(
            "Pas de quit pour "
            .. self:appDisplayName(appInfo)
            .. " : "
            .. allowedReason,
            true
        )

        return self

    end


    if self:isInStartupGrace() then

        self:log(
            "Pas de quit pour "
            .. self:appDisplayName(appInfo)
            .. " : grace de demarrage",
            true
        )


        return self

    end


    self:cancelPendingQuit(
        appInfo,
        "nouvelle planification"
    )


    self.pendingQuits[key] =
        {
            bundleID = appInfo.bundleID,
            name = appInfo.name,
            reason = reason,
            startedAt = self:now(),
            timer = hs.timer.doAfter(
                self.quitDelay,
                function()

                    self:confirmAndQuit(
                        appInfo.bundleID,
                        appInfo.name
                    )

                end
            ),
        }


    self:log(
        string.format(
            "Quit programme pour %s dans %s (%s)",
            self:appDisplayName(appInfo),
            self:formatDuration(self.quitDelay),
            reason or "derniere fenetre fermee"
        ),
        true
    )


    self:updateMenuBar()


    return self

end


function obj:confirmAndQuit(bundleID, name)

    local appInfo =
        self:appInfoFromBundleID(
            bundleID,
            name
        )


    local key =
        self:appKey(appInfo)


    if key then

        self.pendingQuits[key] =
            nil

    end


    local application =
        appInfo and appInfo.app


    if not application then

        self:log(
            "Quit ignore pour "
            .. tostring(name or bundleID)
            .. " : app deja fermee",
            true
        )

        self:updateMenuBar()

        return self

    end


    if not self.enabled
        or self:isPaused() then

        self:log(
            "Quit ignore pour "
            .. self:appDisplayName(appInfo)
            .. " : desactive ou pause",
            true
        )

        self:updateMenuBar()

        return self

    end


    local allowed,
          allowedReason =
        self:isApplicationAllowed(appInfo)


    if not allowed then

        self:log(
            "Quit ignore pour "
            .. self:appDisplayName(appInfo)
            .. " : "
            .. allowedReason,
            true
        )

        self:updateMenuBar()

        return self

    end


    local count =
        self:countWindows(application)


    if count > 0 then

        self:log(
            string.format(
                "Quit ignore pour %s : %d fenetre(s) encore ouverte(s)",
                self:appDisplayName(appInfo),
                count
            ),
            true
        )

        self:updateMenuBar()

        return self

    end


    if not self:hasSeen(appInfo) then

        self:log(
            "Quit ignore pour "
            .. self:appDisplayName(appInfo)
            .. " : app jamais vue avec fenetre",
            true
        )

        self:updateMenuBar()

        return self

    end


    local ok,
          result =
        pcall(
            function()

                return application:kill()

            end
        )


    self:log(
        string.format(
            "Quit execute pour %s : %s",
            self:appDisplayName(appInfo),
            tostring(ok and result ~= false)
        ),
        true
    )


    self:updateMenuBar()


    return self

end



------------------------------------------------------------
-- EVENEMENTS
------------------------------------------------------------

function obj:onWindowCreated(window, appName)

    local appInfo =
        self:appInfoFromWindow(
            window,
            appName
        )


    self:markSeen(appInfo)


    self:cancelPendingQuit(
        appInfo,
        "nouvelle fenetre"
    )


    self:log(
        "Fenetre creee : "
        .. self:appDisplayName(appInfo)
    )

end


function obj:onWindowDestroyed(window, appName)

    local appInfo =
        self:appInfoFromWindow(
            window,
            appName
        )


    self:markSeen(appInfo)


    self:log(
        "Fenetre fermee : "
        .. self:appDisplayName(appInfo),
        true
    )


    hs.timer.doAfter(
        0.15,
        function()

            local refreshed =
                self:appInfoFromBundleID(
                    appInfo.bundleID,
                    appInfo.name
                )


            if not refreshed
                or not refreshed.app then

                self:log(
                    "Analyse ignoree pour "
                    .. self:appDisplayName(appInfo)
                    .. " : app absente",
                    true
                )

                return

            end


            local count =
                self:countWindows(refreshed.app)


            if count == 0 then

                self:scheduleQuit(
                    refreshed,
                    "derniere fenetre fermee"
                )

            else

                self:log(
                    string.format(
                        "%s conservee : %d fenetre(s) restante(s)",
                        self:appDisplayName(refreshed),
                        count
                    ),
                    true
                )

            end

        end
    )

end


function obj:onApplicationEvent(application, eventType)

    local appInfo =
        self:appInfoFromApplication(
            application
        )


    if not appInfo then

        return

    end


    if eventType == hs.application.watcher.launched then

        hs.timer.doAfter(
            self.scanAfterLaunchDelay,
            function()

                local refreshed =
                    self:appInfoFromBundleID(
                        appInfo.bundleID,
                        appInfo.name
                    )


                if refreshed
                    and refreshed.app
                    and self:countWindows(refreshed.app) > 0 then

                    self:markSeen(refreshed)

                end

            end
        )

    elseif eventType == hs.application.watcher.terminated then

        self:cancelPendingQuit(
            appInfo,
            "application terminee"
        )

    end

end



------------------------------------------------------------
-- CONTROLES
------------------------------------------------------------

function obj:enable()

    self.enabled =
        true


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Active",
        true
    )


    return self

end


function obj:disable()

    self.enabled =
        false


    for _, pending in pairs(self.pendingQuits) do

        if pending.timer then

            pending.timer:stop()

        end

    end


    self.pendingQuits =
        {}


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Desactive",
        true
    )


    return self

end


function obj:toggle()

    if self.enabled then

        return self:disable()

    end


    return self:enable()

end


function obj:setQuitDelay(seconds)

    self.quitDelay =
        math.max(
            0,
            tonumber(seconds) or 2
        )


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Delai de quit : "
        .. self:formatDuration(self.quitDelay),
        true
    )


    return self

end


function obj:addAppToBlacklist(appInfo)

    if not appInfo then

        return self

    end


    if appInfo.bundleID then

        if self.useIgnoredBundlesFile then

            self:addBundleIDToIgnoredFile(
                appInfo.bundleID
            )

        else

            self.blacklistBundleIDs[appInfo.bundleID] =
                true

        end

    elseif appInfo.name then

        self.blacklistAppNames[appInfo.name] =
            true

    end


    self:cancelPendingQuit(
        appInfo,
        "ajout a la blacklist"
    )


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Ajout blacklist : "
        .. self:appDisplayName(appInfo),
        true
    )


    return self

end


function obj:removeBundleIDFromBlacklist(bundleID)

    if self.useIgnoredBundlesFile
        and self.ignoredBundlesFileEntries[bundleID] then

        self:removeBundleIDFromIgnoredFile(
            bundleID
        )

    else

        self.blacklistBundleIDs[bundleID] =
            nil

    end


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Retrait blacklist bundleID : "
        .. tostring(bundleID),
        true
    )


    return self

end


function obj:removeNameFromBlacklist(name)

    self.blacklistAppNames[name] =
        nil


    self:savePersistentSettings()


    self:updateMenuBar()


    self:log(
        "Retrait blacklist app : "
        .. tostring(name),
        true
    )


    return self

end


function obj:addFocusedAppToBlacklist()

    local application =
        hs.application.frontmostApplication()


    if application then

        self:addAppToBlacklist(
            self:appInfoFromApplication(application)
        )

    end


    return self

end


function obj:clearLogFile()

    local file =
        io.open(
            self.logFile,
            "w"
        )


    if file then

        file:write("")

        file:close()

    end


    self:log(
        "Log vide",
        true
    )


    return self

end


function obj:shellQuote(value)

    value =
        tostring(value or "")


    return "'"
        .. value:gsub(
            "'",
            "'\\''"
        )
        .. "'"

end


function obj:openLogFile()

    hs.execute(
        "/usr/bin/open "
        .. self:shellQuote(self.logFile)
    )


    return self

end


function obj:openIgnoredBundlesFile()

    self:ensureIgnoredBundlesFilePath()


    local file =
        io.open(
            self.ignoredBundlesFile,
            "a"
        )


    if file then

        file:close()

    end


    hs.execute(
        "/usr/bin/open "
        .. self:shellQuote(self.ignoredBundlesFile)
    )


    return self

end


function obj:toggleAutoLaunch()

    local current =
        hs.autoLaunch()


    hs.autoLaunch(
        not current
    )


    self:updateMenuBar()


    self:log(
        "Demarrage a l'ouverture de session : "
        .. tostring(not current),
        true
    )


    return self

end



------------------------------------------------------------
-- MENUBAR
------------------------------------------------------------

function obj:menuIcon()

    if not self.enabled then

        return "LWQ off"

    end


    if self:isPaused() then

        return "LWQ pause"

    end


    if next(self.pendingQuits) then

        return "LWQ ..."

    end


    return "LWQ"

end


function obj:updateMenuBar()

    if not self.menuBar then

        return self

    end


    self.menuBar:setTitle(
        self:menuIcon()
    )


    return self

end


function obj:setMenuBarVisible(visible)

    self.showMenuBar =
        visible == true


    if self.showMenuBar then

        self:createMenuBar()

    elseif self.menuBar then

        self.menuBar:delete()

        self.menuBar =
            nil

    end


    return self

end


function obj:appendBlacklistMenu(menu)

    table.insert(
        menu,
        {
            title = "Blacklist",
            disabled = true,
        }
    )


    table.insert(
        menu,
        {
            title = "Ajouter l'app active",
            fn = function()

                self:addFocusedAppToBlacklist()

            end,
        }
    )


    if self.useIgnoredBundlesFile then

        table.insert(
            menu,
            {
                title =
                    "Ouvrir ignored-bundles.txt",
                fn = function()

                    self:openIgnoredBundlesFile()

                end,
            }
        )


        table.insert(
            menu,
            {
                title =
                    "Recharger ignored-bundles.txt",
                fn = function()

                    self:reloadIgnoredBundlesFile()

                end,
            }
        )

    end


    local bundleIDs =
        self:sortedKeys(self.blacklistBundleIDs)


    local names =
        self:sortedKeys(self.blacklistAppNames)


    if #bundleIDs == 0
        and #names == 0 then

        table.insert(
            menu,
            {
                title = "Aucune app blacklistee",
                disabled = true,
            }
        )

    end


    for _, bundleID in ipairs(bundleIDs) do

        table.insert(
            menu,
            {
                title = "Retirer " .. bundleID,
                fn = function()

                    self:removeBundleIDFromBlacklist(bundleID)

                end,
            }
        )

    end


    for _, name in ipairs(names) do

        table.insert(
            menu,
            {
                title = "Retirer " .. name,
                fn = function()

                    self:removeNameFromBlacklist(name)

                end,
            }
        )

    end


    table.insert(
        menu,
        {
            title = "-",
        }
    )

end


function obj:appendDelayMenu(menu)

    table.insert(
        menu,
        {
            title =
                "Delai actuel : "
                .. self:formatDuration(self.quitDelay),
            disabled = true,
        }
    )


    for _, seconds in ipairs({ 0, 1, 2, 5, 10, 30 }) do

        table.insert(
            menu,
            {
                title =
                    "Delai "
                    .. self:formatDuration(seconds),
                checked = self.quitDelay == seconds,
                fn = function()

                    self:setQuitDelay(seconds)

                end,
            }
        )

    end


    table.insert(
        menu,
        {
            title = "-",
        }
    )

end


function obj:appendPendingMenu(menu)

    local hasPending =
        false


    for _, pending in pairs(self.pendingQuits) do

        hasPending =
            true


        local elapsed =
            self:now() - pending.startedAt


        local remaining =
            math.max(
                0,
                self.quitDelay - elapsed
            )


        table.insert(
            menu,
            {
                title =
                    "Quit en attente : "
                    .. tostring(pending.name or pending.bundleID)
                    .. " ("
                    .. self:formatDuration(remaining)
                    .. ")",
                disabled = true,
            }
        )

    end


    if hasPending then

        table.insert(
            menu,
            {
                title = "Annuler les quits en attente",
                fn = function()

                    for key, pending in pairs(self.pendingQuits) do

                        if pending.timer then

                            pending.timer:stop()

                        end


                        self.pendingQuits[key] =
                            nil

                    end


                    self:updateMenuBar()

                end,
            }
        )


        table.insert(
            menu,
            {
                title = "-",
            }
        )

    end

end


function obj:buildMenu()

    local menu =
        {}


    table.insert(
        menu,
        {
            title =
                "LastWindowQuits "
                .. self.version,
            disabled = true,
        }
    )


    if self:isPaused() then

        table.insert(
            menu,
            {
                title =
                    "Pause restante : "
                    .. self:formatDuration(self.pausedUntil - self:now()),
                disabled = true,
            }
        )

    end


    table.insert(
        menu,
        {
            title = "-",
        }
    )


    table.insert(
        menu,
        {
            title = self.enabled and "Desactiver" or "Activer",
            fn = function()

                self:toggle()

            end,
        }
    )


    if self:isPaused() then

        table.insert(
            menu,
            {
                title = "Reprendre maintenant",
                fn = function()

                    self:resume()

                end,
            }
        )

    else

        table.insert(
            menu,
            {
                title = "Pause 15 min",
                fn = function()

                    self:pauseFor(15 * 60)

                end,
            }
        )


        table.insert(
            menu,
            {
                title = "Pause 1 h",
                fn = function()

                    self:pauseFor(60 * 60)

                end,
            }
        )

    end


    table.insert(
        menu,
        {
            title = "-",
        }
    )


    self:appendPendingMenu(menu)

    self:appendDelayMenu(menu)

    self:appendBlacklistMenu(menu)


    table.insert(
        menu,
        {
            title = "Logs fichier",
            checked = self.logToFile,
            fn = function()

                self.logToFile =
                    not self.logToFile


                self:savePersistentSettings()


                if self.logToFile then

                    self:cleanLogFile(true)

                end


                self:updateMenuBar()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Logs verbeux",
            checked = self.verboseLogging,
            fn = function()

                self.verboseLogging =
                    not self.verboseLogging


                self:savePersistentSettings()


                self:log(
                    "Logs verbeux : "
                    .. tostring(self.verboseLogging),
                    true
                )

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Ouvrir le log",
            fn = function()

                self:openLogFile()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Vider le log",
            fn = function()

                self:clearLogFile()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "-",
        }
    )


    table.insert(
        menu,
        {
            title = "Cacher LWQ dans la barre",
            fn = function()

                self:setMenuBarVisible(false)

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "-",
        }
    )


    table.insert(
        menu,
        {
            title = "Hammerspoon au demarrage",
            checked = hs.autoLaunch(),
            fn = function()

                self:toggleAutoLaunch()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Ouvrir la console Hammerspoon",
            fn = function()

                hs.openConsole()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Recharger Hammerspoon",
            fn = function()

                hs.reload()

            end,
        }
    )


    table.insert(
        menu,
        {
            title = "Quitter Hammerspoon",
            fn = function()

                local application =
                    hs.application.get("Hammerspoon")


                if application then

                    application:kill()

                end

            end,
        }
    )


    return menu

end


function obj:showMenu()

    if not self.menuBar then

        return

    end


    self.menuBar:setMenu(
        self:buildMenu()
    )


    local frame =
        self.menuBar:frame()


    if not frame then

        self.menuBar:setMenu(nil)

        return

    end


    self.menuBar:popupMenu({
        x = frame.x,
        y = frame.y + frame.h,
    })


    hs.timer.doAfter(
        0.1,
        function()

            if self.menuBar then

                self.menuBar:setMenu(nil)

            end

        end
    )

end


function obj:handleMenuBarClick()

    self.clickCount =
        self.clickCount + 1


    if self.clickCount == 1 then

        self.clickTimer =
            hs.timer.doAfter(
                self.doubleClickInterval,
                function()

                    if self.clickCount == 1 then

                        self:showMenu()

                    end


                    self.clickCount =
                        0


                    self.clickTimer =
                        nil

                end
            )


        return

    end


    if self.clickCount >= 2 then

        if self.clickTimer then

            self.clickTimer:stop()

            self.clickTimer =
                nil

        end


        self.clickCount =
            0


        self:toggle()

    end

end


function obj:createMenuBar()

    if not self.showMenuBar then

        return self

    end


    if self.menuBar then

        self:updateMenuBar()

        return self

    end


    self.menuBar =
        hs.menubar.new()


    if not self.menuBar then

        self:log(
            "ERREUR creation menubar",
            true
        )

        return self

    end


    self:updateMenuBar()


    self.menuBar:setClickCallback(
        function()

            self:handleMenuBarClick()

        end
    )


    return self

end



------------------------------------------------------------
-- WATCHERS
------------------------------------------------------------

function obj:createWindowFilter()

    if self.windowFilter then

        return self

    end


    self.windowFilter =
        hs.window.filter.default


    self.windowCreatedCallback =
        function(window, appName)

            self:onWindowCreated(
                window,
                appName
            )

        end


    self.windowDestroyedCallback =
        function(window, appName)

            self:onWindowDestroyed(
                window,
                appName
            )

        end


    self.windowFilter:subscribe(
        hs.window.filter.windowCreated,
        self.windowCreatedCallback
    )


    self.windowFilter:subscribe(
        hs.window.filter.windowDestroyed,
        self.windowDestroyedCallback
    )


    return self

end


function obj:createAppWatcher()

    if self.appWatcher then

        return self

    end


    self.appWatcher =
        hs.application.watcher.new(
            function(_, eventType, application)

                self:onApplicationEvent(
                    application,
                    eventType
                )

            end
        )


    self.appWatcher:start()


    return self

end


function obj:primeSeenApps()

    for _, application in ipairs(hs.application.runningApplications()) do

        local appInfo =
            self:appInfoFromApplication(application)


        if appInfo
            and application
            and self:countWindows(application) > 0 then

            self:markSeen(appInfo)

        end

    end


    return self

end



------------------------------------------------------------
-- HOTKEYS
------------------------------------------------------------

function obj:bindHotkeys(mapping)

    for _, hotkey in pairs(self.hotkeys) do

        if hotkey then

            hotkey:delete()

        end

    end


    self.hotkeys =
        {}


    if mapping
        and mapping.toggle
        and mapping.toggle[1]
        and mapping.toggle[2] then

        self.hotkeys.toggle =
            hs.hotkey.bind(
                mapping.toggle[1],
                mapping.toggle[2],
                function()

                    self:toggle()

                end
            )

    end


    if mapping
        and mapping.pause
        and mapping.pause[1]
        and mapping.pause[2] then

        self.hotkeys.pause =
            hs.hotkey.bind(
                mapping.pause[1],
                mapping.pause[2],
                function()

                    self:pauseFor(15 * 60)

                end
            )

    end


    if mapping
        and mapping.resume
        and mapping.resume[1]
        and mapping.resume[2] then

        self.hotkeys.resume =
            hs.hotkey.bind(
                mapping.resume[1],
                mapping.resume[2],
                function()

                    self:resume()

                end
            )

    end


    return self

end



------------------------------------------------------------
-- START / STOP
------------------------------------------------------------

function obj:start()

    self.startedAt =
        self:now()


    self:ensureIgnoredBundlesFilePath()

    self:mergePersistentSettings()

    self:reloadIgnoredBundlesFile()

    self:cleanLogFile(true)

    self:createMenuBar()

    self:createWindowFilter()

    self:createAppWatcher()

    self:primeSeenApps()

    self:updateMenuBar()

    self:log(
        "Spoon initialise",
        true
    )

    return self

end


function obj:stop()

    for _, pending in pairs(self.pendingQuits) do

        if pending.timer then

            pending.timer:stop()

        end

    end


    self.pendingQuits =
        {}


    if self.windowFilter then

        if self.windowCreatedCallback then

            self.windowFilter:unsubscribe(
                self.windowCreatedCallback
            )

        end


        if self.windowDestroyedCallback then

            self.windowFilter:unsubscribe(
                self.windowDestroyedCallback
            )

        end

        self.windowFilter =
            nil

    end


    self.windowCreatedCallback =
        nil


    self.windowDestroyedCallback =
        nil


    if self.appWatcher then

        self.appWatcher:stop()

        self.appWatcher =
            nil

    end


    if self.clickTimer then

        self.clickTimer:stop()

        self.clickTimer =
            nil

    end


    for _, hotkey in pairs(self.hotkeys) do

        if hotkey then

            hotkey:delete()

        end

    end


    self.hotkeys =
        {}


    if self.menuBar then

        self.menuBar:delete()

        self.menuBar =
            nil

    end


    self:log(
        "Spoon arrete",
        true
    )


    return self

end


return obj
