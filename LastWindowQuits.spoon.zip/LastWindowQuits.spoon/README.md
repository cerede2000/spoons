# LastWindowQuits.spoon

Spoon Hammerspoon qui quitte automatiquement une application quand sa derniere fenetre est fermee.

## Installation

Copier le dossier `LastWindowQuits.spoon` dans :

```text
~/.hammerspoon/Spoons/
```

Puis ajouter dans `~/.hammerspoon/init.lua` :

```lua
hs.loadSpoon("LastWindowQuits")

spoon.LastWindowQuits.quitDelay = 2
spoon.LastWindowQuits.showNotifications = true
spoon.LastWindowQuits.verboseLogging = false
spoon.LastWindowQuits.logToFile = true
spoon.LastWindowQuits.maxLogAgeSeconds = 24 * 60 * 60
spoon.LastWindowQuits.showMenuBar = false

spoon.LastWindowQuits:bindHotkeys({
    toggle = {
        {"ctrl", "alt", "cmd"},
        "Q"
    },
    pause = {
        {"ctrl", "alt", "cmd"},
        "P"
    },
    resume = {
        {"ctrl", "alt", "cmd", "shift"},
        "P"
    },
})

spoon.LastWindowQuits:start()
```

Les bundle IDs ignores se configurent dans le fichier voisin :

```text
~/.hammerspoon/Spoons/LastWindowQuits.spoon/ignored-bundles.txt
```

Format :

```text
com.apple.finder
com.microsoft.Outlook
com.microsoft.teams2
com.objective-see.lulu.app
com.adobe.bridge
com.hnc.discord
com.microsoft.VSCode
com.google.Chrome
```

Une ligne par bundle ID. Les lignes vides et les commentaires commencant par `#` sont ignores.

## Trouver un bundle ID

Depuis la console Hammerspoon, `frontmostApplication()` renvoie souvent Hammerspoon lui-meme, car la console devient l'app active. Chercher donc l'application par nom :

```lua
app = hs.application.find("Microsoft Outlook")
print(app:name(), app:bundleID())
```

```lua
app = hs.application.find("Microsoft Teams")
print(app:name(), app:bundleID())
```

Pour lister les apps ouvertes contenant `Microsoft` :

```lua
for _, app in ipairs(hs.application.runningApplications()) do
    local name = app:name() or ""
    if name:lower():find("microsoft") then
        print(name, app:bundleID())
    end
end
```

Exemples courants :

```text
Microsoft Outlook  com.microsoft.Outlook
Microsoft Teams    com.microsoft.teams2
```

## Fonctionnalites

- Detection des fermetures de fenetres via `hs.window.filter`.
- Quit differe avec `quitDelay` pour eviter les faux positifs.
- Annulation du quit si une nouvelle fenetre apparait avant la fin du timer.
- Blacklist par bundle ID via `ignored-bundles.txt`, ou par nom d'application dans la config Lua.
- Exclusions dediees aux apps de fond, VPN, agents et apps systeme.
- Par defaut, seules les exclusions internes essentielles restent codees en dur : Hammerspoon, System Events et Security Agent.
- Pause temporaire depuis la barre de menus.
- Logs console et fichier `~/.hammerspoon/LastWindowQuits.log`, conserve 1 jour par defaut.
- Option "Hammerspoon au demarrage" depuis le menu.
- Option `showMenuBar = false` pour cacher `LWQ` dans la barre de menu.
- Simple clic sur `LWQ` pour le menu, double clic pour activer/desactiver.

Note : comme l'application d'origine, ce Spoon depend des notifications macOS de fermeture de fenetre. Sur macOS 15 Sequoia, Apple a signale des comportements intermittents sur ces evenements, donc la detection peut parfois etre incomplete.
